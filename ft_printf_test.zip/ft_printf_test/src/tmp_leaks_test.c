/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_test.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vmonteco                                   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/05/04 01:23:12 by vmonteco          #+#    #+#             */
/*   Updated: 2017/05/18 17:39:48 by vmonteco         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */
/*                                                                            */
/*                                   headers                                  */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <limits.h>
#include "libftprintf.h"

#define MY_TOSTRING(X) #X
#define MY_STRINGIFY(X) MY_TOSTRING(X)
#define PRINT_CASE(...) printf("\"%s\" :\n", MY_STRINGIFY(__VA_ARGS__));

#define TEST_VAL(CS, VAL)						\
	ft_printf(CS, VAL);

#define TEST_CONV_SPEC(CS)							\
	TEST_VAL(CS, NULL);								\
	TEST_VAL(CS, "")								\
	TEST_VAL(CS, "foo");							\
	TEST_VAL(CS, "\x262D");							\
	TEST_VAL(CS, 'a');								\
	TEST_VAL(CS, 0x262D);							\
	TEST_VAL(CS, 0);								\
	TEST_VAL(CS, 1);								\
	TEST_VAL(CS, -1);								\
	TEST_VAL(CS, SHRT_MIN);							\
	TEST_VAL(CS, SHRT_MAX);							\
	TEST_VAL(CS, USHRT_MAX);						\
	TEST_VAL(CS, CHAR_MIN);							\
	TEST_VAL(CS, CHAR_MAX);							\
	TEST_VAL(CS, UCHAR_MAX);						\
	TEST_VAL(CS, INT_MIN);							\
	TEST_VAL(CS, INT_MAX);							\
	TEST_VAL(CS, UINT_MAX);							\
	TEST_VAL(CS, LONG_MIN);							\
	TEST_VAL(CS, LONG_MAX);							\
	TEST_VAL(CS, ULONG_MAX);						\
	TEST_VAL(CS, LLONG_MIN);						\
	TEST_VAL(CS, LLONG_MAX);						\
	TEST_VAL(CS, ULLONG_MAX);

#define TEST_LEN_MOD(LM)						\
	TEST_CONV_SPEC(LM"c");						\
	TEST_CONV_SPEC(LM"C");						\
	TEST_CONV_SPEC(LM"%");						\
	TEST_CONV_SPEC(LM"s");						\
	TEST_CONV_SPEC(LM"S");						\
	TEST_CONV_SPEC(LM"p");						\
	TEST_CONV_SPEC(LM"d");						\
	TEST_CONV_SPEC(LM"D");						\
	TEST_CONV_SPEC(LM"x");						\
	TEST_CONV_SPEC(LM"X");						\
	TEST_CONV_SPEC(LM"u");						\
	TEST_CONV_SPEC(LM"U");						\
	TEST_CONV_SPEC(LM"i");						\
	TEST_CONV_SPEC(LM"o");						\
	TEST_CONV_SPEC(LM"O");

#define TEST_PRECISION(PR)							\
	TEST_LEN_MOD(PR);								\
	TEST_LEN_MOD(PR".");							\
	TEST_LEN_MOD(PR"foo");							\
	TEST_LEN_MOD(PR".foo");							\
	TEST_LEN_MOD(PR".bar");							\
	TEST_LEN_MOD(PR"0");							\
	TEST_LEN_MOD(PR".0");							\
	TEST_LEN_MOD(PR".0");							\
	TEST_LEN_MOD(PR".0");							\
	TEST_LEN_MOD(PR".5");							\
	TEST_LEN_MOD(PR".10");							\
	TEST_LEN_MOD(PR".50");

#define TEST_MIN_LEN(ML)						\
	TEST_PRECISION(ML);							\
	TEST_PRECISION(ML"bar");					\
	TEST_PRECISION(ML"0");						\
	TEST_PRECISION(ML"1");						\
	TEST_PRECISION(ML"-1");						\
	TEST_PRECISION(ML"10");						\
	TEST_PRECISION(ML"-10");					\
	TEST_PRECISION(ML"-100");					\
	TEST_PRECISION(ML"1000000000000000000");

#define TEST_OPT_LVL5(ML)						\
	TEST_MIN_LEN(ML);							\
	TEST_MIN_LEN(ML" ");						\
	TEST_MIN_LEN(ML"+");						\
	TEST_MIN_LEN(ML"-");						\
	TEST_MIN_LEN(ML"0");						\
	TEST_MIN_LEN(ML"#");

#define TEST_OPT_LVL4(ML)						\
	TEST_OPT_LVL5(ML);							\
	TEST_OPT_LVL5(ML" ");						\
	TEST_OPT_LVL5(ML"+");						\
	TEST_OPT_LVL5(ML"-");						\
	TEST_OPT_LVL5(ML"0");						\
	TEST_OPT_LVL5(ML"#");

#define TEST_OPT_LVL3(ML)						\
	TEST_OPT_LVL4(ML);							\
	TEST_OPT_LVL4(ML" ");						\
	TEST_OPT_LVL4(ML"+");						\
	TEST_OPT_LVL4(ML"-");						\
	TEST_OPT_LVL4(ML"0");						\
	TEST_OPT_LVL4(ML"#");

#define TEST_OPT_LVL2(ML)						\
	TEST_OPT_LVL3(ML);							\
	TEST_OPT_LVL3(ML" ");						\
	TEST_OPT_LVL3(ML"+");						\
	TEST_OPT_LVL3(ML"-");						\
	TEST_OPT_LVL3(ML"0");						\
	TEST_OPT_LVL3(ML"#");

#define TEST									\
	TEST_OPT_LVL2("");							\
	TEST_OPT_LVL2(" ");							\
	TEST_OPT_LVL2("+");							\
	TEST_OPT_LVL2("-");							\
	TEST_OPT_LVL2("0");							\
	TEST_OPT_LVL2("#");


/* ************************************************************************** */
/*                             test function                                  */
/* ************************************************************************** */

void	ft_printf_test_leaks(void)
{
	setlocale(LC_ALL, "");
	TEST;
	while (1);
}
