/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_test.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vmonteco                                   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/05/04 01:23:12 by vmonteco          #+#    #+#             */
/*   Updated: 2017/05/15 18:54:16 by vmonteco         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */
/*                                                                            */
/*                                   headers                                  */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <wchar.h>
#include <limits.h>
#include <sys/wait.h>
#include <stddef.h>
#include "libftprintf.h"


/* ************************************************************************** */
/*                                                                            */
/*                          t_result type definition                          */
/*                                                                            */
/* ************************************************************************** */

typedef struct		s_result
{
	int		f1_child_status;
	int		f1_return;
	char	*f1_output;
	int		f2_child_status;
	int		f2_return;
	char	*f2_output;	
}					t_result;


/* ************************************************************************** */
/*                                                                            */
/*                                   colors                                   */
/*                                                                            */
/* ************************************************************************** */

#define RESET_COLOR "\x1b[0m"
#define RED_COLOR "\x1b[31m"
#define GREEN_COLOR "\x1b[32m"
#define BLUE_COLOR "\e[0;34m"
#define CYAN_COLOR "\e[0;36m"
#define YELLOW_COLOR "\e[0;33m"
#define PURPLE_COLOR "\e[0;35m"


/* ************************************************************************** */
/*                                                                            */
/*                              useful macros                                 */
/*                                                                            */
/* ************************************************************************** */

#define BUFFSIZE 256
#define TEST_STR(...) #__VA_ARGS__
#define TEST_TOSTRING(...) TEST_STR(__VA_ARGS__)


/* ************************************************************************** */
/*                                                                            */
/*                       Macros to tests in child processes                   */
/*                              and to get the result.                        */
/*                                                                            */
/* ************************************************************************** */

#define TESTFUNCTIONS(F1, F2, ...)										\
	init_result(&results);												\
	/* f1 */															\
	pipe_output_status = pipe(pipe_output);								\
	if (!pipe_output_status)											\
	{																	\
		pipe_return_value_status = pipe(pipe_return_value);				\
		if (pipe_return_value_status)									\
		{																\
			close(pipe_output[0]);										\
			close(pipe_output[1]);										\
		}																\
	}																	\
	if (pipe_output_status || pipe_return_value_status)					\
	{																	\
		printf("Unable to open pipes.\n");								\
	}																	\
	else																\
	{																	\
		f1_child_pid = fork();											\
		if (f1_child_pid == -1)											\
		{																\
			printf("Unable to fork.");									\
		}																\
		else if (f1_child_pid == 0)										\
		{																\
			close(pipe_output[0]);										\
			close(pipe_return_value[0]);								\
			dup2(pipe_output[1], 1);									\
			tmp_return = F1(__VA_ARGS__);								\
			pipe_return_value_status = write(pipe_return_value[1],		\
											 &tmp_return,				\
											 sizeof(tmp_return));		\
			close(pipe_output[1]);										\
			close(pipe_return_value[1]);								\
			if (results.f1_return == -1 || pipe_return_value_status == -1) \
				exit(EXIT_FAILURE);										\
			exit(EXIT_SUCCESS);											\
		}																\
		else															\
		{																\
			close(pipe_output[1]);										\
			close(pipe_return_value[1]);								\
			results.f1_output = read_fd(pipe_output[0]);				\
			pipe_return_value_status = read(pipe_return_value[0],		\
											&(results.f1_return),		\
											sizeof(results.f1_return));	\
			waitpid(f1_child_pid, &(results.f1_child_status), 0);		\
			close(pipe_output[0]);										\
			close(pipe_return_value[0]);								\
		}																\
	}																	\
	/* f2 */															\
	pipe_output_status = pipe(pipe_output);								\
	if (!pipe_output_status)											\
	{																	\
		pipe_return_value_status = pipe(pipe_return_value);				\
		if (pipe_return_value_status)									\
		{																\
			close(pipe_output[0]);										\
			close(pipe_output[1]);										\
		}																\
	}																	\
	if (pipe_output_status || pipe_return_value_status)					\
		printf("Unable to open pipes.\n");								\
	else																\
	{																	\
		f2_child_pid = fork();											\
		if (f2_child_pid == -1)											\
		{																\
			printf("Unable to fork.");									\
		}																\
		else if (f2_child_pid == 0)										\
		{																\
			close(pipe_output[0]);										\
			close(pipe_return_value[0]);								\
			dup2(pipe_output[1], 1);									\
			tmp_return = F2(__VA_ARGS__);								\
			pipe_return_value_status = write(pipe_return_value[1],		\
											 &tmp_return,				\
											 sizeof(tmp_return));		\
			close(pipe_output[1]);										\
			close(pipe_return_value[1]);								\
			if (results.f2_return == -1 || pipe_return_value_status == -1) \
				exit(EXIT_FAILURE);										\
			exit(EXIT_SUCCESS);											\
		}																\
		else															\
		{																\
			close(pipe_output[1]);										\
			close(pipe_return_value[1]);								\
			results.f2_output = read_fd(pipe_output[0]);				\
			pipe_return_value_status = read(pipe_return_value[0],		\
											&(results.f2_return),		\
											sizeof(results.f2_return));	\
			waitpid(f2_child_pid, &(results.f2_child_status), 0);		\
			close(pipe_output[0]);										\
			close(pipe_return_value[0]);								\
		}																\
	}																	\
	interpret_results(&results, &lcl_success_cnt, &ttl_success_cnt,		\
					  &lcl_cnt, &ttl_cnt, TEST_TOSTRING(__VA_ARGS__), verbose); \
	delete_result(&results);
// The two first arguments are the functions to compare.
#define TEST(...) TESTFUNCTIONS(printf, ft_printf, __VA_ARGS__)


/* ************************************************************************** */
/*                                                                            */
/*                            tool functions.                                 */
/*                                                                            */
/* ************************************************************************** */

char	*new_strnew(size_t size)
{
	char	*res;

	if ((res = (char *)malloc(sizeof(char) * size)))
		bzero(res, size);
	return (res);
}

char	*new_strjoin(char *s1, char *s2)
{
	char	*res;

	res = NULL;
	if (s1 && s2 && (res = new_strnew(strlen(s1) + strlen(s2) + 1)))
	{
		strcpy(res, s1);
		strcpy(&res[strlen(s1)], s2);
	}
	return (res);
}

void	new_strdel(char **as)
{
	if (as && *as)
	{
		free(*as);
		*as = NULL;
	}
}

char	*read_fd(int fd)
{
	char	*res;
	char	*tmp;
	int		status;
	char	buf[BUFFSIZE];

	bzero(buf, BUFFSIZE);
	res = strdup("");
	if (res){
		while ((status = read(fd, &buf, BUFFSIZE)))
		{
			tmp = new_strjoin(res, buf);
			bzero(buf, BUFFSIZE);
			new_strdel(&res);
			if (!tmp)
				return (NULL);
			res = tmp;
		}
		if (status < 0)
			new_strdel(&res);
	}
	return (res);
}

void	init_result(t_result *results)
{
	if (results)
	{
		results->f1_child_status = 0;
		results->f1_return = 0;
		results->f1_output = NULL;
		results->f2_child_status = 0;
		results->f2_return = 0;
		results->f2_output = NULL;
	}
}

void	delete_result(t_result *results)
{
	if (results)
	{
		new_strdel(&(results->f1_output));
		new_strdel(&(results->f2_output));
	}
}

char	*new_stringify(char *s)
{
	int		i, j, k;
	char	*tmp;
	
	if (!s)
		return (NULL);
	i = 0;
	j = 0;
	while (s[i])
	{
		if ((s[i] >= '\a' && s[i] <= '\r') || s[i] == '\\' || s[i] == '"')
			j++;
		i++;
	}
	k = strlen(s);
	if ((tmp = new_strnew(j + k + 2 + 1)))
	{
		*tmp = '"';
		tmp[j + k + 1] = '"';
		i = 1;
		j = 0;
		while (tmp[i] != '"' && s[j])
		{
			if ((s[j] >= '\a' && s[j] <= '\r') || s[j] == '\\' || s[j] == '"')
			{
				tmp[i] = '\\';
				i++;
				switch (s[j]) {
				case '\a':
					tmp[i] = 'a';
					break;
				case '\b':
					tmp[i] = 'b';
					break;
				case '\t':
					tmp[i] = 't';
					break;
				case '\n':
					tmp[i] = 'n';
					break;
				case '\v':
					tmp[i] = 'v';
					break;
				case '\f':
					tmp[i] = 'f';
					break;
				case '\r':
					tmp[i] = 'r';
					break;
				case '\\':
					tmp[i] = '\\';
					break;
				case '"':
					tmp[i] = '"';
					break;
				}
			}
			else
				tmp[i] = s[j];
			i++;
			j++;
		}
	}
	return tmp;
}

void	interpret_results(t_result *res, int *lcl_success, int *ttl_success, int *lcl, int *ttl, char *test_case, int verbose)
{
	char	*f1_stringified;
	char	*f2_stringified;
	
	if (res->f1_child_status == res->f2_child_status
		&& (res->f1_child_status != 0
			|| (res->f1_return == res->f2_return
				&& strcmp(res->f1_output, res->f2_output) == 0)))
	{
		if (verbose)
		{
			if (res->f1_child_status)
			{
				printf("[%s%30s%s] -> [printf/ft_printf][%s%20s%s/%s%20s%s]\n",
					   PURPLE_COLOR, test_case, RESET_COLOR,
					   GREEN_COLOR, "An error occured.", RESET_COLOR,
					   GREEN_COLOR, "An error occured.", RESET_COLOR);
			}
			else
			{
				f1_stringified = new_stringify(res->f1_output);
				f2_stringified = new_stringify(res->f2_output);
				printf("[%s%30s%s] -> [printf/ft_printf][%s%3d%s/%s%3d%s][%s%20s%s/%s%20s%s]\n",
					   PURPLE_COLOR, test_case, RESET_COLOR,
					   GREEN_COLOR, res->f1_return, RESET_COLOR,
					   GREEN_COLOR, res->f2_return, RESET_COLOR,
					   GREEN_COLOR, f1_stringified, RESET_COLOR,
					   GREEN_COLOR, f2_stringified, RESET_COLOR);
				new_strdel(&f1_stringified);
				new_strdel(&f2_stringified);
			}
		}
		(*lcl_success)++;
		(*ttl_success)++;
	}
	else
	{
		if (res->f1_child_status || res->f2_child_status)
		{
			printf("[%s%30s%s] -> [printf/ft_printf][%s%3d%s/%s%3d%s] (different child statuses, an error occured).\n",
				   PURPLE_COLOR, test_case, RESET_COLOR,
				   GREEN_COLOR, res->f1_child_status, RESET_COLOR,
				   RED_COLOR, res->f2_child_status, RESET_COLOR);
		}
		else
		{
			f1_stringified = new_stringify(res->f1_output);
			f2_stringified = new_stringify(res->f2_output);
			printf("[%s%30s%s] -> [printf/ft_printf][%s%3d%s/%s%3d%s][%s%20s%s/%s%20s%s]\n",
				   PURPLE_COLOR, test_case, RESET_COLOR,
				   GREEN_COLOR, res->f1_return, RESET_COLOR,
				   res->f1_return == res->f2_return ? GREEN_COLOR : RED_COLOR,
				   res->f2_return, RESET_COLOR,
				   GREEN_COLOR, f1_stringified, RESET_COLOR,
				   strcmp(res->f1_output, res->f2_output) == 0 ? GREEN_COLOR : RED_COLOR,
				   f2_stringified, RESET_COLOR);
			new_strdel(&f1_stringified);
			new_strdel(&f2_stringified);

		}
	}
	(*ttl)++;
	(*lcl)++;
}

void	results_summary(char *name, int *success, int *total)
{
	if (success && total)
	{
		printf("%s[%s] tests passed : [%s%3d%s/%3d].%s\n",
			   CYAN_COLOR, name,
			   *success == *total ? GREEN_COLOR : RED_COLOR,
			   *success, CYAN_COLOR, *total, RESET_COLOR);
		*success = 0;
		*total = 0;
	}
}

/* ************************************************************************** */
/*                                                                            */
/*                               actual tests                                 */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */
/*                                subtests                                    */
/* ************************************************************************** */

#define TEST_NUM_DI_SUBTESTS(CS, VAL)			\
	TEST("%" CS, VAL);							\
	TEST("% " CS, VAL);							\
	TEST("%+" CS, VAL);							\
	TEST("%-" CS, VAL);							\
	TEST("% 0" CS, VAL);						\
	TEST("% -" CS, VAL);						\
	TEST("%+0" CS, VAL);						\
	TEST("%+-" CS, VAL);						\
	TEST("% 04" CS, VAL);						\
	TEST("% -4" CS, VAL);						\
	TEST("%+04" CS, VAL);						\
	TEST("%+-4" CS, VAL);						\
	TEST("% 0.4" CS, VAL);						\
	TEST("% -.4" CS, VAL);						\
	TEST("%+0.4" CS, VAL);						\
	TEST("%+-.4" CS, VAL);						\
	TEST("% 04.4" CS, VAL);						\
	TEST("% -4.4" CS, VAL);						\
	TEST("%+04.4" CS, VAL);						\
	TEST("%+-4.4" CS, VAL);

#define TEST_NUM_OXUOUX(CS, VAL)				\
	TEST("%" CS, VAL);							\
	TEST("%#" CS, VAL);							\
	TEST("%-" CS, VAL);							\
	TEST("%0" CS, VAL);							\
	TEST("%#-" CS, VAL);						\
	TEST("%#0" CS, VAL);						\
	TEST("%14" CS, VAL);						\
	TEST("%#14" CS, VAL);						\
	TEST("%-14" CS, VAL);						\
	TEST("%014" CS, VAL);						\
	TEST("%#-14" CS, VAL);						\
	TEST("%#014" CS, VAL);						\
	TEST("%14.4" CS, VAL);						\
	TEST("%#14.4" CS, VAL);						\
	TEST("%-14.4" CS, VAL);						\
	TEST("%014.4" CS, VAL);						\
	TEST("%#-14.4" CS, VAL);					\
	TEST("%#014.4" CS, VAL);					\
	TEST("%.4" CS, VAL);						\
	TEST("%#.4" CS, VAL);						\
	TEST("%-.4" CS, VAL);						\
	TEST("%0.4" CS, VAL);						\
	TEST("%#-.4" CS, VAL);						\
	TEST("%#0.4" CS, VAL);


#define TEST_NUM_UUU(CS, VAL)					\
	TEST("%" CS, VAL);							\
	TEST("%-" CS, VAL);							\
	TEST("%0" CS, VAL);							\
	TEST("%14" CS, VAL);						\
	TEST("%-14" CS, VAL);						\
	TEST("%014" CS, VAL);						\
	TEST("%14.4" CS, VAL);						\
	TEST("%-14.4" CS, VAL);						\
	TEST("%014.4" CS, VAL);						\
	TEST("%.4" CS, VAL);						\
	TEST("%-.4" CS, VAL);						\
	TEST("%0.4" CS, VAL);



#define TEST_NUM_P_SUBTESTS(VAL)				\
	TEST("%p", VAL);							\
	TEST("%-p", VAL);							\
	TEST("%14p", VAL);							\
	TEST("%-14p", VAL);

/* ************************************************************************** */
/*                                    raw                                     */
/* ************************************************************************** */

#define TESTS_RAW										\
	TEST("TEST");										\
	TEST("\n");											\
	TEST("foobar  foobar\tfoobar\nfoobarxiv\n\n\t\\.");	\
	results_summary("raw", &lcl_success_cnt, &lcl_cnt)


/* ************************************************************************** */
/*                                  percent                                   */
/* ************************************************************************** */

#define TESTS_PERCENT										\
	TEST("%%");												\
	TEST("foo%%");											\
	TEST("bar%%");											\
	TEST("foo%%bar");										\
	TEST("foo%%bar%%foobar%%barbar");						\
	results_summary("%% test", &lcl_success_cnt, &lcl_cnt)


/* ************************************************************************** */
/*                               c conv spec                                  */
/* ************************************************************************** */

#define TESTS_C														\
	TEST("%c", 'a');												\
	TEST("%5c", 'a');												\
	TEST("%-c", 'a');												\
	TEST("%-5c", 'a');												\
	TEST("%lc", (wint_t)0x262D);									\
	TEST("%5lc", (wint_t)0x262D);									\
	TEST("%-lc", (wint_t)0x262D);									\
	TEST("%-5lc", (wint_t)0x262D);									\
	TEST("%lc", 0x262D);											\
	TEST("%5lc", 0x262D);											\
	TEST("%-lc", 0x262D);											\
	TEST("%-5lc", 0x262D);											\
	results_summary("c conv specifier", &lcl_success_cnt, &lcl_cnt)


/* ************************************************************************** */
/*                               C conv spec                                  */
/* ************************************************************************** */

#define TESTS_UC													\
	TEST("%C", 'a');												\
	TEST("%5C", 'a');												\
	TEST("%-C", 'a');												\
	TEST("%-5C", 'a');												\
	TEST("%C", (wint_t)0x262D);										\
	TEST("%5C", (wint_t)0x262D);									\
	TEST("%-C", (wint_t)0x262D);									\
	TEST("%-5C", (wint_t)0x262D);									\
	TEST("%C", 0x262D);												\
	TEST("%5C", 0x262D);											\
	TEST("%-C", 0x262D);											\
	TEST("%-5C", 0x262D);											\
	results_summary("C conv specifier", &lcl_success_cnt, &lcl_cnt)


/* ************************************************************************** */
/*                               s conv spec                                  */
/* ************************************************************************** */

#define TESTS_S														\
	TEST("%s", "c");												\
	TEST("%s$\n", "");												\
	TEST("%-s$\n", "");												\
	TEST("%10s$\n", "");											\
	TEST("%-10s$\n", "");											\
	TEST("%.2s$\n", "");											\
	TEST("%-.2s$\n", "");											\
	TEST("%10.2s$\n", "");											\
	TEST("%-10.2s$\n", "");											\
	TEST("%.6s$\n", "");											\
	TEST("%-.6s$\n", "");											\
	TEST("%10.6s$\n", "");											\
	TEST("%-10.6s$\n", "");											\
	TEST("%ls$\n", (wchar_t *) L"");								\
	TEST("%-ls$\n", (wchar_t *) L"");								\
	TEST("%10ls$\n", (wchar_t *) L"");								\
	TEST("%-10ls$\n", (wchar_t *) L"");								\
	TEST("%.2ls$\n", (wchar_t *) L"");								\
	TEST("%-.2ls$\n", (wchar_t *) L"");								\
	TEST("%10.2ls$\n", (wchar_t *) L"");							\
	TEST("%-10.2ls$\n", (wchar_t *) L"");							\
	TEST("%.6ls$\n", (wchar_t *) L"");								\
	TEST("%-.6ls$\n", (wchar_t *) L"");								\
	TEST("%10.6ls$\n", (wchar_t *) L"");							\
	TEST("%-10.6ls$\n", (wchar_t *) L"");							\
	TEST("%s$\n", NULL);											\
	TEST("%-s$\n", NULL);											\
	TEST("%10s$\n", NULL);											\
	TEST("%-10s$\n", NULL);											\
	TEST("%.2s$\n", NULL);											\
	TEST("%-.2s$\n", NULL);											\
	TEST("%10.2s$\n", NULL);										\
	TEST("%-10.2s$\n", NULL);										\
	TEST("%.6s$\n", NULL);											\
	TEST("%-.6s$\n", NULL);											\
	TEST("%10.6s$\n", NULL);										\
	TEST("%-10.6s$\n", NULL);										\
	TEST("%ls$\n", (wchar_t *) NULL);								\
	TEST("%-ls$\n", (wchar_t *) NULL);								\
	TEST("%10ls$\n", (wchar_t *) NULL);								\
	TEST("%-10ls$\n", (wchar_t *) NULL);							\
	TEST("%.2ls$\n", (wchar_t *) NULL);								\
	TEST("%-.2ls$\n", (wchar_t *) NULL);							\
	TEST("%10.2ls$\n", (wchar_t *) NULL);							\
	TEST("%-10.2ls$\n", (wchar_t *) NULL);							\
	TEST("%.6ls$\n", (wchar_t *) NULL);								\
	TEST("%-.6ls$\n", (wchar_t *) NULL);							\
	TEST("%10.6ls$\n", (wchar_t *) NULL);							\
	TEST("%-10.6ls$\n", (wchar_t *) NULL);							\
	TEST("%s$\n", "foo");											\
	TEST("%-s$\n", "foo");											\
	TEST("%10s$\n", "foo");											\
	TEST("%-10s$\n", "foo");										\
	TEST("%.2s$\n", "foo");											\
	TEST("%-.2s$\n", "foo");										\
	TEST("%10.2s$\n", "foo");										\
	TEST("%-10.2s$\n", "foo");										\
	TEST("%ls$\n", L"\x262D\x262D\x262D");							\
	TEST("%-ls$\n", L"\x262D\x262D\x262D");							\
	TEST("%10ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.ls$\n", L"\x262D\x262D\x262D");							\
	TEST("%-.ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.0ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-.0ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.0ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.0ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.1ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-.1ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.1ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.1ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.2ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-.2ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.2ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.2ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.3ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-.3ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.3ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.3ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.4ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-.4ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.4ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.4ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.5ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-.5ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.5ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.5ls$\n", L"\x262D\x262D\x262D");						\
	results_summary("s conv specifier", &lcl_success_cnt, &lcl_cnt)


/* ************************************************************************** */
/*                               S conv spec                                  */
/* ************************************************************************** */

#define TESTS_US													\
	TEST("%S", L"S");												\
	TEST("%S$\n", L"\x262D\x262D\x262D");							\
	TEST("%-S$\n", L"\x262D\x262D\x262D");							\
	TEST("%10S$\n", L"\x262D\x262D\x262D");							\
	TEST("%-10S$\n", L"\x262D\x262D\x262D");						\
	TEST("%S$\n", L"");												\
	TEST("%-S$\n", L"");											\
	TEST("%10S$\n", L"");											\
	TEST("%-10S$\n", L"");											\
	TEST("%S$\n", (wchar_t *)NULL);									\
	TEST("%-S$\n", (wchar_t *)NULL);								\
	TEST("%10S$\n", (wchar_t *)NULL);								\
	TEST("%-10S$\n", (wchar_t *)NULL);								\
	TEST("%-10S$\n", (wchar_t *)NULL);								\
	results_summary("S conv specifier", &lcl_success_cnt, &lcl_cnt)

/* ************************************************************************** */
/*                               p conv spec                                  */
/* ************************************************************************** */

#define TESTS_P														\
	TEST_NUM_P_SUBTESTS(NULL);										\
	/* TEST_NUM_P_SUBTESTS(foo_str); */								\
	TEST_NUM_P_SUBTESTS((void *)ptr);								\
	results_summary("p conv specifier", &lcl_success_cnt, &lcl_cnt)


/* ************************************************************************** */
/*                               d conv spec                                  */
/* ************************************************************************** */

#define TESTS_D														\
	TEST_NUM_DI_SUBTESTS("d", 0);									\
	TEST_NUM_DI_SUBTESTS("lld", (long long) 0);						\
	TEST_NUM_DI_SUBTESTS("ld", (long) 0);							\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) 0);					\
	TEST_NUM_DI_SUBTESTS("hd", (short) 0);							\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) 0);						\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) 0);							\
	TEST_NUM_DI_SUBTESTS("d", 1);									\
	TEST_NUM_DI_SUBTESTS("lld", (long long) 1);						\
	TEST_NUM_DI_SUBTESTS("ld", (long) 1);							\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) 1);					\
	TEST_NUM_DI_SUBTESTS("hd", (short) 1);							\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) 1);						\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) 1);							\
	TEST_NUM_DI_SUBTESTS("d", -1);									\
	TEST_NUM_DI_SUBTESTS("lld", (long long) -1);					\
	TEST_NUM_DI_SUBTESTS("ld", (long) -1);							\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) -1);					\
	TEST_NUM_DI_SUBTESTS("hd", (short) -1);							\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) -1);						\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) -1);						\
	TEST_NUM_DI_SUBTESTS("d", SHRT_MIN);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) SHRT_MIN);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) SHRT_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) SHRT_MIN);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) SHRT_MIN);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) SHRT_MIN);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) SHRT_MIN);					\
	TEST_NUM_DI_SUBTESTS("d", SHRT_MAX);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) SHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) SHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) SHRT_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) SHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) SHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) SHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("d", USHRT_MAX);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) USHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) USHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) USHRT_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) USHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) USHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) USHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("d", CHAR_MIN);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) CHAR_MIN);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) CHAR_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) CHAR_MIN);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) CHAR_MIN);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) CHAR_MIN);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) CHAR_MIN);					\
	TEST_NUM_DI_SUBTESTS("d", CHAR_MAX);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) CHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) CHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) CHAR_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) CHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) CHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) CHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("d", UCHAR_MAX);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) UCHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) UCHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) UCHAR_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) UCHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) UCHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) UCHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("d", INT_MIN);								\
	TEST_NUM_DI_SUBTESTS("lld", (long long) INT_MIN);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) INT_MIN);						\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) INT_MIN);				\
	TEST_NUM_DI_SUBTESTS("hd", (short) INT_MIN);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) INT_MIN);					\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) INT_MIN);					\
	TEST_NUM_DI_SUBTESTS("d", INT_MAX);								\
	TEST_NUM_DI_SUBTESTS("lld", (long long) INT_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) INT_MAX);						\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) INT_MAX);				\
	TEST_NUM_DI_SUBTESTS("hd", (short) INT_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) INT_MAX);					\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) INT_MAX);					\
	TEST_NUM_DI_SUBTESTS("d", UINT_MAX);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) UINT_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) UINT_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) UINT_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) UINT_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) UINT_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) UINT_MAX);					\
	TEST_NUM_DI_SUBTESTS("lld", (long long) LONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) LONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) LONG_MIN);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) LONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) LONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) LONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("lld", (long long) LONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) LONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) LONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) LONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) LONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) LONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("lld", (long long) ULONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) ULONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) ULONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) ULONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) ULONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) ULONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("lld", (long long) LLONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) LLONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) LLONG_MIN);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) LLONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) LLONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) LLONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("lld", (long long) LLONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) LLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) LLONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) LLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) LLONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) LLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("lld", (long long) ULLONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("ld", (long) ULLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) ULLONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) ULLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) ULLONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) ULLONG_MAX);				\
	results_summary("d conv specifier", &lcl_success_cnt, &lcl_cnt)
 

/* ************************************************************************** */
/*                               D conv spec                                  */
/* ************************************************************************** */

#define TESTS_UD													\
	TEST_NUM_DI_SUBTESTS("D",  0);									\
	TEST_NUM_DI_SUBTESTS("D",  1);									\
	TEST_NUM_DI_SUBTESTS("D",  -1);									\
	TEST_NUM_DI_SUBTESTS("D",  SHRT_MIN);							\
	TEST_NUM_DI_SUBTESTS("D",  SHRT_MAX);							\
	TEST_NUM_DI_SUBTESTS("D",  USHRT_MAX);							\
	TEST_NUM_DI_SUBTESTS("D",  CHAR_MIN);							\
	TEST_NUM_DI_SUBTESTS("D",  CHAR_MAX);							\
	TEST_NUM_DI_SUBTESTS("D",  UCHAR_MAX);							\
	TEST_NUM_DI_SUBTESTS("D",  INT_MIN);							\
	TEST_NUM_DI_SUBTESTS("D",  INT_MAX);							\
	TEST_NUM_DI_SUBTESTS("D",  UINT_MAX);							\
	TEST_NUM_DI_SUBTESTS("D", (int) LONG_MIN);						\
	TEST_NUM_DI_SUBTESTS("D", (int) LONG_MAX);						\
	TEST_NUM_DI_SUBTESTS("D", (int) ULONG_MAX);						\
	TEST_NUM_DI_SUBTESTS("D", (int) LLONG_MIN);						\
	TEST_NUM_DI_SUBTESTS("D", (int) LLONG_MAX);						\
	TEST_NUM_DI_SUBTESTS("D", (int) ULLONG_MAX);					\
	results_summary("D conv specifier", &lcl_success_cnt, &lcl_cnt)


/* ************************************************************************** */
/*                               i conv spec                                  */
/* ************************************************************************** */

#define TESTS_I														\
	TEST_NUM_DI_SUBTESTS("i", 0);									\
	TEST_NUM_DI_SUBTESTS("lli", (long long) 0);						\
	TEST_NUM_DI_SUBTESTS("li", (long) 0);							\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) 0);					\
	TEST_NUM_DI_SUBTESTS("hi", (short) 0);							\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) 0);						\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) 0);							\
	TEST_NUM_DI_SUBTESTS("i", 1);									\
	TEST_NUM_DI_SUBTESTS("lli", (long long) 1);						\
	TEST_NUM_DI_SUBTESTS("li", (long) 1);							\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) 1);					\
	TEST_NUM_DI_SUBTESTS("hi", (short) 1);							\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) 1);						\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) 1);							\
	TEST_NUM_DI_SUBTESTS("i", -1);									\
	TEST_NUM_DI_SUBTESTS("lli", (long long) -1);					\
	TEST_NUM_DI_SUBTESTS("li", (long) -1);							\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) -1);					\
	TEST_NUM_DI_SUBTESTS("hi", (short) -1);							\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) -1);						\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) -1);						\
	TEST_NUM_DI_SUBTESTS("i", SHRT_MIN);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) SHRT_MIN);				\
	TEST_NUM_DI_SUBTESTS("li", (long) SHRT_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) SHRT_MIN);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) SHRT_MIN);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) SHRT_MIN);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) SHRT_MIN);					\
	TEST_NUM_DI_SUBTESTS("i", SHRT_MAX);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) SHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) SHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) SHRT_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) SHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) SHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) SHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("i", USHRT_MAX);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) USHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) USHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) USHRT_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) USHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) USHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) USHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("i", CHAR_MIN);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) CHAR_MIN);				\
	TEST_NUM_DI_SUBTESTS("li", (long) CHAR_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) CHAR_MIN);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) CHAR_MIN);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) CHAR_MIN);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) CHAR_MIN);					\
	TEST_NUM_DI_SUBTESTS("i", CHAR_MAX);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) CHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) CHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) CHAR_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) CHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) CHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) CHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("i", UCHAR_MAX);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) UCHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) UCHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) UCHAR_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) UCHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) UCHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) UCHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("i", INT_MIN);								\
	TEST_NUM_DI_SUBTESTS("lli", (long long) INT_MIN);				\
	TEST_NUM_DI_SUBTESTS("li", (long) INT_MIN);						\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) INT_MIN);				\
	TEST_NUM_DI_SUBTESTS("hi", (short) INT_MIN);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) INT_MIN);					\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) INT_MIN);					\
	TEST_NUM_DI_SUBTESTS("i", INT_MAX);								\
	TEST_NUM_DI_SUBTESTS("lli", (long long) INT_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) INT_MAX);						\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) INT_MAX);				\
	TEST_NUM_DI_SUBTESTS("hi", (short) INT_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) INT_MAX);					\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) INT_MAX);					\
	TEST_NUM_DI_SUBTESTS("i", UINT_MAX);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) UINT_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) UINT_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) UINT_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) UINT_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) UINT_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) UINT_MAX);					\
	TEST_NUM_DI_SUBTESTS("lli", (long long) LONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("li", (long) LONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) LONG_MIN);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) LONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) LONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) LONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("lli", (long long) LONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) LONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) LONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) LONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) LONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) LONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("lli", (long long) ULONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) ULONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) ULONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) ULONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) ULONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) ULONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("lli", (long long) LLONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("li", (long) LLONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) LLONG_MIN);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) LLONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) LLONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) LLONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("lli", (long long) LLONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) LLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) LLONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) LLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) LLONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) LLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("lli", (long long) ULLONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("li", (long) ULLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) ULLONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) ULLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) ULLONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) ULLONG_MAX);				\
	results_summary("i conv specifier", &lcl_success_cnt, &lcl_cnt)


/* ************************************************************************** */
/*                               o conv spec                                  */
/* ************************************************************************** */

#define TESTS_O														\
	TEST_NUM_OXUOUX("o", 0);										\
	TEST_NUM_OXUOUX("hho", (unsigned char) 0);						\
	TEST_NUM_OXUOUX("ho", (unsigned short) 0);						\
	TEST_NUM_OXUOUX("llo", (unsigned long long) 0);					\
	TEST_NUM_OXUOUX("lo", (unsigned long)0);						\
	TEST_NUM_OXUOUX("jo", (uintmax_t) 0);							\
	TEST_NUM_OXUOUX("zo", (size_t) 0);								\
	TEST_NUM_OXUOUX("o", 1);										\
	TEST_NUM_OXUOUX("hho", (unsigned char) 1);						\
	TEST_NUM_OXUOUX("ho", (unsigned short) 1);						\
	TEST_NUM_OXUOUX("llo", (unsigned long long) 1);					\
	TEST_NUM_OXUOUX("lo", (unsigned long) 1);						\
	TEST_NUM_OXUOUX("jo", (uintmax_t) 1);							\
	TEST_NUM_OXUOUX("zo", (size_t) 1);								\
	TEST_NUM_OXUOUX("o", -1);										\
	TEST_NUM_OXUOUX("hho", (unsigned char) -1);						\
	TEST_NUM_OXUOUX("ho", (unsigned short) -1);						\
	TEST_NUM_OXUOUX("llo", (unsigned long long) -1);				\
	TEST_NUM_OXUOUX("lo", (unsigned long) -1);						\
	TEST_NUM_OXUOUX("jo", (uintmax_t) -1);							\
	TEST_NUM_OXUOUX("zo", (size_t) -1);								\
	TEST_NUM_OXUOUX("o", SHRT_MIN);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) SHRT_MIN);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) SHRT_MIN);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) SHRT_MIN);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) SHRT_MIN);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) SHRT_MIN);					\
	TEST_NUM_OXUOUX("zo", (size_t) SHRT_MIN);						\
	TEST_NUM_OXUOUX("o", SHRT_MAX);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) SHRT_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) SHRT_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) SHRT_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) SHRT_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) SHRT_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) SHRT_MAX);						\
	TEST_NUM_OXUOUX("o", USHRT_MAX);								\
	TEST_NUM_OXUOUX("hho", (unsigned char) USHRT_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) USHRT_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) USHRT_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) USHRT_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) USHRT_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) USHRT_MAX);						\
	TEST_NUM_OXUOUX("o", CHAR_MIN);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) CHAR_MIN);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) CHAR_MIN);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) CHAR_MIN);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) CHAR_MIN);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) CHAR_MIN);					\
	TEST_NUM_OXUOUX("zo", (size_t) CHAR_MIN);						\
	TEST_NUM_OXUOUX("o", CHAR_MAX);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) CHAR_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) CHAR_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) CHAR_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) CHAR_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) CHAR_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) CHAR_MAX);						\
	TEST_NUM_OXUOUX("o", UCHAR_MAX);								\
	TEST_NUM_OXUOUX("hho", (unsigned char) UCHAR_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) UCHAR_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) UCHAR_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) UCHAR_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) UCHAR_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) UCHAR_MAX);						\
	TEST_NUM_OXUOUX("o", INT_MIN);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) INT_MIN);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) INT_MIN);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) INT_MIN);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) INT_MIN);					\
	TEST_NUM_OXUOUX("jo", (uintmax_t) INT_MIN);						\
	TEST_NUM_OXUOUX("zo", (size_t) INT_MIN);						\
	TEST_NUM_OXUOUX("o", INT_MAX);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) INT_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) INT_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) INT_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) INT_MAX);					\
	TEST_NUM_OXUOUX("jo", (uintmax_t) INT_MAX);						\
	TEST_NUM_OXUOUX("zo", (size_t) INT_MAX);						\
	TEST_NUM_OXUOUX("o", UINT_MAX);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) UINT_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) UINT_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) UINT_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) UINT_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) UINT_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) UINT_MAX);						\
	TEST_NUM_OXUOUX("o", (unsigned int) LONG_MIN);					\
	TEST_NUM_OXUOUX("hho", (unsigned char) LONG_MIN);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) LONG_MIN);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) LONG_MIN);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) LONG_MIN);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) LONG_MIN);					\
	TEST_NUM_OXUOUX("zo", (size_t) LONG_MIN);						\
	TEST_NUM_OXUOUX("o", (unsigned int) LONG_MAX);					\
	TEST_NUM_OXUOUX("hho", (unsigned char) LONG_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) LONG_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) LONG_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) LONG_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) LONG_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) LONG_MAX);						\
	TEST_NUM_OXUOUX("o", (unsigned int) ULONG_MAX);					\
	TEST_NUM_OXUOUX("hho", (unsigned char) ULONG_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) ULONG_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) ULONG_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) ULONG_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) ULONG_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) ULONG_MAX);						\
	TEST_NUM_OXUOUX("o", (unsigned int) LLONG_MIN);					\
	TEST_NUM_OXUOUX("hho", (unsigned char) LLONG_MIN);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) LLONG_MIN);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) LLONG_MIN);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) LLONG_MIN);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) LLONG_MIN);					\
	TEST_NUM_OXUOUX("zo", (size_t) LLONG_MIN);						\
	TEST_NUM_OXUOUX("o", (unsigned int) LLONG_MAX);					\
	TEST_NUM_OXUOUX("hho", (unsigned char) LLONG_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) LLONG_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) LLONG_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) LLONG_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) LLONG_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) LLONG_MAX);						\
	TEST_NUM_OXUOUX("o", (unsigned int) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("hho", (unsigned char) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) ULLONG_MAX);		\
	TEST_NUM_OXUOUX("lo", (unsigned long) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) ULLONG_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) ULLONG_MAX);						\
	results_summary("o conv specifier", &lcl_success_cnt, &lcl_cnt)


/* ************************************************************************** */
/*                               O conv spec                                  */
/* ************************************************************************** */

#define TESTS_UO													\
	TEST_NUM_OXUOUX("O",  0);										\
	TEST_NUM_OXUOUX("O",  1);										\
	TEST_NUM_OXUOUX("O",  -1);										\
	TEST_NUM_OXUOUX("O",  SHRT_MIN);								\
	TEST_NUM_OXUOUX("O",  SHRT_MAX);								\
	TEST_NUM_OXUOUX("O",  USHRT_MAX);								\
	TEST_NUM_OXUOUX("O",  CHAR_MIN);								\
	TEST_NUM_OXUOUX("O",  CHAR_MAX);								\
	TEST_NUM_OXUOUX("O",  UCHAR_MAX);								\
	TEST_NUM_OXUOUX("O",  INT_MIN);									\
	TEST_NUM_OXUOUX("O",  INT_MAX);									\
	TEST_NUM_OXUOUX("O",  UINT_MAX);								\
	TEST_NUM_OXUOUX("O", (unsigned int) LONG_MIN);					\
	TEST_NUM_OXUOUX("O", (unsigned int) LONG_MAX);					\
	TEST_NUM_OXUOUX("O", (unsigned int) ULONG_MAX);					\
	TEST_NUM_OXUOUX("O", (unsigned int) LLONG_MIN);					\
	TEST_NUM_OXUOUX("O", (unsigned int) LLONG_MAX);					\
	TEST_NUM_OXUOUX("O", (unsigned int) ULLONG_MAX);				\
	results_summary("O conv specifier", &lcl_success_cnt, &lcl_cnt)


/* ************************************************************************** */
/*                               u conv spec                                  */
/* ************************************************************************** */

#define TESTS_U														\
	TEST_NUM_UUU("u", 0);											\
	TEST_NUM_UUU("hhu", (unsigned char) 0);							\
	TEST_NUM_UUU("hu", (unsigned short) 0);							\
	TEST_NUM_UUU("llu", (unsigned long long) 0);					\
	TEST_NUM_UUU("lu", (unsigned long)0);							\
	TEST_NUM_UUU("ju", (uintmax_t) 0);								\
	TEST_NUM_UUU("zu", (size_t) 0);									\
	TEST_NUM_UUU("u", 1);											\
	TEST_NUM_UUU("hhu", (unsigned char) 1);							\
	TEST_NUM_UUU("hu", (unsigned short) 1);							\
	TEST_NUM_UUU("llu", (unsigned long long) 1);					\
	TEST_NUM_UUU("lu", (unsigned long) 1);							\
	TEST_NUM_UUU("ju", (uintmax_t) 1);								\
	TEST_NUM_UUU("zu", (size_t) 1);									\
	TEST_NUM_UUU("u", -1);											\
	TEST_NUM_UUU("hhu", (unsigned char) -1);						\
	TEST_NUM_UUU("hu", (unsigned short) -1);						\
	TEST_NUM_UUU("llu", (unsigned long long) -1);					\
	TEST_NUM_UUU("lu", (unsigned long) -1);							\
	TEST_NUM_UUU("ju", (uintmax_t) -1);								\
	TEST_NUM_UUU("zu", (size_t) -1);								\
	TEST_NUM_UUU("u", SHRT_MIN);									\
	TEST_NUM_UUU("hhu", (unsigned char) SHRT_MIN);					\
	TEST_NUM_UUU("hu", (unsigned short) SHRT_MIN);					\
	TEST_NUM_UUU("llu", (unsigned long long) SHRT_MIN);				\
	TEST_NUM_UUU("lu", (unsigned long) SHRT_MIN);					\
	TEST_NUM_UUU("ju", (uintmax_t) SHRT_MIN);						\
	TEST_NUM_UUU("zu", (size_t) SHRT_MIN);							\
	TEST_NUM_UUU("u", SHRT_MAX);									\
	TEST_NUM_UUU("hhu", (unsigned char) SHRT_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) SHRT_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) SHRT_MAX);				\
	TEST_NUM_UUU("lu", (unsigned long) SHRT_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) SHRT_MAX);						\
	TEST_NUM_UUU("zu", (size_t) SHRT_MAX);							\
	TEST_NUM_UUU("u", USHRT_MAX);									\
	TEST_NUM_UUU("hhu", (unsigned char) USHRT_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) USHRT_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) USHRT_MAX);			\
	TEST_NUM_UUU("lu", (unsigned long) USHRT_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) USHRT_MAX);						\
	TEST_NUM_UUU("zu", (size_t) USHRT_MAX);							\
	TEST_NUM_UUU("u", CHAR_MIN);									\
	TEST_NUM_UUU("hhu", (unsigned char) CHAR_MIN);					\
	TEST_NUM_UUU("hu", (unsigned short) CHAR_MIN);					\
	TEST_NUM_UUU("llu", (unsigned long long) CHAR_MIN);				\
	TEST_NUM_UUU("lu", (unsigned long) CHAR_MIN);					\
	TEST_NUM_UUU("ju", (uintmax_t) CHAR_MIN);						\
	TEST_NUM_UUU("zu", (size_t) CHAR_MIN);							\
	TEST_NUM_UUU("u", CHAR_MAX);									\
	TEST_NUM_UUU("hhu", (unsigned char) CHAR_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) CHAR_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) CHAR_MAX);				\
	TEST_NUM_UUU("lu", (unsigned long) CHAR_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) CHAR_MAX);						\
	TEST_NUM_UUU("zu", (size_t) CHAR_MAX);							\
	TEST_NUM_UUU("u", UCHAR_MAX);									\
	TEST_NUM_UUU("hhu", (unsigned char) UCHAR_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) UCHAR_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) UCHAR_MAX);			\
	TEST_NUM_UUU("lu", (unsigned long) UCHAR_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) UCHAR_MAX);						\
	TEST_NUM_UUU("zu", (size_t) UCHAR_MAX);							\
	TEST_NUM_UUU("u", INT_MIN);										\
	TEST_NUM_UUU("hhu", (unsigned char) INT_MIN);					\
	TEST_NUM_UUU("hu", (unsigned short) INT_MIN);					\
	TEST_NUM_UUU("llu", (unsigned long long) INT_MIN);				\
	TEST_NUM_UUU("lu", (unsigned long) INT_MIN);					\
	TEST_NUM_UUU("ju", (uintmax_t) INT_MIN);						\
	TEST_NUM_UUU("zu", (size_t) INT_MIN);							\
	TEST_NUM_UUU("u", INT_MAX);										\
	TEST_NUM_UUU("hhu", (unsigned char) INT_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) INT_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) INT_MAX);				\
	TEST_NUM_UUU("lu", (unsigned long) INT_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) INT_MAX);						\
	TEST_NUM_UUU("zu", (size_t) INT_MAX);							\
	TEST_NUM_UUU("u", UINT_MAX);									\
	TEST_NUM_UUU("hhu", (unsigned char) UINT_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) UINT_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) UINT_MAX);				\
	TEST_NUM_UUU("lu", (unsigned long) UINT_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) UINT_MAX);						\
	TEST_NUM_UUU("zu", (size_t) UINT_MAX);							\
	TEST_NUM_UUU("u", (unsigned int) LONG_MIN);						\
	TEST_NUM_UUU("hhu", (unsigned char) LONG_MIN);					\
	TEST_NUM_UUU("hu", (unsigned short) LONG_MIN);					\
	TEST_NUM_UUU("llu", (unsigned long long) LONG_MIN);				\
	TEST_NUM_UUU("lu", (unsigned long) LONG_MIN);					\
	TEST_NUM_UUU("ju", (uintmax_t) LONG_MIN);						\
	TEST_NUM_UUU("zu", (size_t) LONG_MIN);							\
	TEST_NUM_UUU("u", (unsigned int) LONG_MAX);						\
	TEST_NUM_UUU("hhu", (unsigned char) LONG_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) LONG_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) LONG_MAX);				\
	TEST_NUM_UUU("lu", (unsigned long) LONG_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) LONG_MAX);						\
	TEST_NUM_UUU("zu", (size_t) LONG_MAX);							\
	TEST_NUM_UUU("u", (unsigned int) ULONG_MAX);					\
	TEST_NUM_UUU("hhu", (unsigned char) ULONG_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) ULONG_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) ULONG_MAX);			\
	TEST_NUM_UUU("lu", (unsigned long) ULONG_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) ULONG_MAX);						\
	TEST_NUM_UUU("zu", (size_t) ULONG_MAX);							\
	TEST_NUM_UUU("u", (unsigned int) LLONG_MIN);					\
	TEST_NUM_UUU("hhu", (unsigned char) LLONG_MIN);					\
	TEST_NUM_UUU("hu", (unsigned short) LLONG_MIN);					\
	TEST_NUM_UUU("llu", (unsigned long long) LLONG_MIN);			\
	TEST_NUM_UUU("lu", (unsigned long) LLONG_MIN);					\
	TEST_NUM_UUU("ju", (uintmax_t) LLONG_MIN);						\
	TEST_NUM_UUU("zu", (size_t) LLONG_MIN);							\
	TEST_NUM_UUU("u", (unsigned int) LLONG_MAX);					\
	TEST_NUM_UUU("hhu", (unsigned char) LLONG_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) LLONG_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) LLONG_MAX);			\
	TEST_NUM_UUU("lu", (unsigned long) LLONG_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) LLONG_MAX);						\
	TEST_NUM_UUU("zu", (size_t) LLONG_MAX);							\
	TEST_NUM_UUU("u", (unsigned int) ULLONG_MAX);					\
	TEST_NUM_UUU("hhu", (unsigned char) ULLONG_MAX);				\
	TEST_NUM_UUU("hu", (unsigned short) ULLONG_MAX);				\
	TEST_NUM_UUU("llu", (unsigned long long) ULLONG_MAX);			\
	TEST_NUM_UUU("lu", (unsigned long) ULLONG_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) ULLONG_MAX);						\
	TEST_NUM_UUU("zu", (size_t) ULLONG_MAX);						\
	results_summary("u conv specifier", &lcl_success_cnt, &lcl_cnt)


/* ************************************************************************** */
/*                               U conv spec                                  */
/* ************************************************************************** */

#define TESTS_UU													\
	TEST_NUM_UUU("U",  0);											\
	TEST_NUM_UUU("U",  1);											\
	TEST_NUM_UUU("U",  -1);											\
	TEST_NUM_UUU("U",  SHRT_MIN);									\
	TEST_NUM_UUU("U",  SHRT_MAX);									\
	TEST_NUM_UUU("U",  USHRT_MAX);									\
	TEST_NUM_UUU("U",  CHAR_MIN);									\
	TEST_NUM_UUU("U",  CHAR_MAX);									\
	TEST_NUM_UUU("U",  UCHAR_MAX);									\
	TEST_NUM_UUU("U",  INT_MIN);									\
	TEST_NUM_UUU("U",  INT_MAX);									\
	TEST_NUM_UUU("U",  UINT_MAX);									\
	TEST_NUM_UUU("U", (unsigned int) LONG_MIN);						\
	TEST_NUM_UUU("U", (unsigned int) LONG_MAX);						\
	TEST_NUM_UUU("U", (unsigned int) ULONG_MAX);					\
	TEST_NUM_UUU("U", (unsigned int) LLONG_MIN);					\
	TEST_NUM_UUU("U", (unsigned int) LLONG_MAX);					\
	TEST_NUM_UUU("U", (unsigned int) ULLONG_MAX);					\
	results_summary("U conv specifier", &lcl_success_cnt, &lcl_cnt)


/* ************************************************************************** */
/*                               x conv spec                                  */
/* ************************************************************************** */

#define TESTS_X														\
	TEST_NUM_OXUOUX("x", 0);										\
	TEST_NUM_OXUOUX("hhx", (unsigned char) 0);						\
	TEST_NUM_OXUOUX("hx", (unsigned short) 0);						\
	TEST_NUM_OXUOUX("llx", (unsigned long long) 0);					\
	TEST_NUM_OXUOUX("lx", (unsigned long)0);						\
	TEST_NUM_OXUOUX("jx", (uintmax_t) 0);							\
	TEST_NUM_OXUOUX("zx", (size_t) 0);								\
	TEST_NUM_OXUOUX("x", 1);										\
	TEST_NUM_OXUOUX("hhx", (unsigned char) 1);						\
	TEST_NUM_OXUOUX("hx", (unsigned short) 1);						\
	TEST_NUM_OXUOUX("llx", (unsigned long long) 1);					\
	TEST_NUM_OXUOUX("lx", (unsigned long) 1);						\
	TEST_NUM_OXUOUX("jx", (uintmax_t) 1);							\
	TEST_NUM_OXUOUX("zx", (size_t) 1);								\
	TEST_NUM_OXUOUX("x", -1);										\
	TEST_NUM_OXUOUX("hhx", (unsigned char) -1);						\
	TEST_NUM_OXUOUX("hx", (unsigned short) -1);						\
	TEST_NUM_OXUOUX("llx", (unsigned long long) -1);				\
	TEST_NUM_OXUOUX("lx", (unsigned long) -1);						\
	TEST_NUM_OXUOUX("jx", (uintmax_t) -1);							\
	TEST_NUM_OXUOUX("zx", (size_t) -1);								\
	TEST_NUM_OXUOUX("x", SHRT_MIN);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) SHRT_MIN);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) SHRT_MIN);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) SHRT_MIN);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) SHRT_MIN);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) SHRT_MIN);					\
	TEST_NUM_OXUOUX("zx", (size_t) SHRT_MIN);						\
	TEST_NUM_OXUOUX("x", SHRT_MAX);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) SHRT_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) SHRT_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) SHRT_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) SHRT_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) SHRT_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) SHRT_MAX);						\
	TEST_NUM_OXUOUX("x", USHRT_MAX);								\
	TEST_NUM_OXUOUX("hhx", (unsigned char) USHRT_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) USHRT_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) USHRT_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) USHRT_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) USHRT_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) USHRT_MAX);						\
	TEST_NUM_OXUOUX("x", CHAR_MIN);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) CHAR_MIN);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) CHAR_MIN);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) CHAR_MIN);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) CHAR_MIN);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) CHAR_MIN);					\
	TEST_NUM_OXUOUX("zx", (size_t) CHAR_MIN);						\
	TEST_NUM_OXUOUX("x", CHAR_MAX);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) CHAR_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) CHAR_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) CHAR_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) CHAR_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) CHAR_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) CHAR_MAX);						\
	TEST_NUM_OXUOUX("x", UCHAR_MAX);								\
	TEST_NUM_OXUOUX("hhx", (unsigned char) UCHAR_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) UCHAR_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) UCHAR_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) UCHAR_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) UCHAR_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) UCHAR_MAX);						\
	TEST_NUM_OXUOUX("x", INT_MIN);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) INT_MIN);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) INT_MIN);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) INT_MIN);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) INT_MIN);					\
	TEST_NUM_OXUOUX("jx", (uintmax_t) INT_MIN);						\
	TEST_NUM_OXUOUX("zx", (size_t) INT_MIN);						\
	TEST_NUM_OXUOUX("x", INT_MAX);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) INT_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) INT_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) INT_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) INT_MAX);					\
	TEST_NUM_OXUOUX("jx", (uintmax_t) INT_MAX);						\
	TEST_NUM_OXUOUX("zx", (size_t) INT_MAX);						\
	TEST_NUM_OXUOUX("x", UINT_MAX);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) UINT_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) UINT_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) UINT_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) UINT_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) UINT_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) UINT_MAX);						\
	TEST_NUM_OXUOUX("x", (unsigned int) LONG_MIN);					\
	TEST_NUM_OXUOUX("hhx", (unsigned char) LONG_MIN);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) LONG_MIN);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) LONG_MIN);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) LONG_MIN);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) LONG_MIN);					\
	TEST_NUM_OXUOUX("zx", (size_t) LONG_MIN);						\
	TEST_NUM_OXUOUX("x", (unsigned int) LONG_MAX);					\
	TEST_NUM_OXUOUX("hhx", (unsigned char) LONG_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) LONG_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) LONG_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) LONG_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) LONG_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) LONG_MAX);						\
	TEST_NUM_OXUOUX("x", (unsigned int) ULONG_MAX);					\
	TEST_NUM_OXUOUX("hhx", (unsigned char) ULONG_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) ULONG_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) ULONG_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) ULONG_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) ULONG_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) ULONG_MAX);						\
	TEST_NUM_OXUOUX("x", (unsigned int) LLONG_MIN);					\
	TEST_NUM_OXUOUX("hhx", (unsigned char) LLONG_MIN);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) LLONG_MIN);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) LLONG_MIN);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) LLONG_MIN);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) LLONG_MIN);					\
	TEST_NUM_OXUOUX("zx", (size_t) LLONG_MIN);						\
	TEST_NUM_OXUOUX("x", (unsigned int) LLONG_MAX);					\
	TEST_NUM_OXUOUX("hhx", (unsigned char) LLONG_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) LLONG_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) LLONG_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) LLONG_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) LLONG_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) LLONG_MAX);						\
	TEST_NUM_OXUOUX("x", (unsigned int) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("hhx", (unsigned char) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) ULLONG_MAX);		\
	TEST_NUM_OXUOUX("lx", (unsigned long) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) ULLONG_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) ULLONG_MAX);						\
	results_summary("x conv specifier", &lcl_success_cnt, &lcl_cnt)

	
/* ************************************************************************** */
/*                               X conv spec                                  */
/* ************************************************************************** */

#define TESTS_UX													\
	TEST_NUM_OXUOUX("X",  0);										\
	TEST_NUM_OXUOUX("X",  1);										\
	TEST_NUM_OXUOUX("X",  -1);										\
	TEST_NUM_OXUOUX("X",  SHRT_MIN);								\
	TEST_NUM_OXUOUX("X",  SHRT_MAX);								\
	TEST_NUM_OXUOUX("X",  USHRT_MAX);								\
	TEST_NUM_OXUOUX("X",  CHAR_MIN);								\
	TEST_NUM_OXUOUX("X",  CHAR_MAX);								\
	TEST_NUM_OXUOUX("X",  UCHAR_MAX);								\
	TEST_NUM_OXUOUX("X",  INT_MIN);									\
	TEST_NUM_OXUOUX("X",  INT_MAX);									\
	TEST_NUM_OXUOUX("X",  UINT_MAX);								\
	TEST_NUM_OXUOUX("X", (unsigned int) LONG_MIN);					\
	TEST_NUM_OXUOUX("X", (unsigned int) LONG_MAX);					\
	TEST_NUM_OXUOUX("X", (unsigned int) ULONG_MAX);					\
	TEST_NUM_OXUOUX("X", (unsigned int) LLONG_MIN);					\
	TEST_NUM_OXUOUX("X", (unsigned int) LLONG_MAX);					\
	TEST_NUM_OXUOUX("X", (unsigned int) ULLONG_MAX);				\
	results_summary("X conv specifier", &lcl_success_cnt, &lcl_cnt)


/* ************************************************************************** */
/*                                  Misc.                                     */
/* ************************************************************************** */

#define TESTS_MISC														\
	TEST("%% %c %C %s %S %d %D %i %p %o %O %x %X %u %U",				\
		 'a', 0x262D, "a", L"\x262D", 42, 42, 42,						\
		 (void *) 424242, 42, 42424242, 42, 42424242, 42, 42424242);	\
	results_summary("X conv specifier", &lcl_success_cnt, &lcl_cnt)

/* ************************************************************************** */
/*                             test function                                  */
/* ************************************************************************** */

void	ft_printf_test(int verbose)
{
	t_result	results;
	// Pipes used.
	int		pipe_output[2];
	int		pipe_return_value[2];
	// Pipe Status values
	int		pipe_output_status;
	int		pipe_return_value_status;
	// child pid :
	pid_t	f1_child_pid;
	pid_t	f2_child_pid;
	int		tmp_return;

	// result counts :
	int		ttl_success_cnt = 0;
	int		ttl_cnt = 0;
	int		lcl_success_cnt = 0;
	int		lcl_cnt = 0;

	// values :
	/* char	*foo_str = "foo"; */
	void	*ptr = (void *)0x123afd;
	
	init_result(&results);
	setlocale(LC_ALL, "");
	tmp_return = 0;
	TESTS_RAW;
	TESTS_PERCENT;
	TESTS_C;
	TESTS_UC;
	TESTS_S;
	TESTS_US;
	TESTS_D;
	TESTS_UD;
	TESTS_I;
	TESTS_P;
	TESTS_O;
	TESTS_UO;
	TESTS_U;
	TESTS_UU;
	TESTS_X;
	TESTS_UX;
	TESTS_MISC;
	results_summary("total", &ttl_success_cnt, &ttl_cnt);
	delete_result(&results);
}
