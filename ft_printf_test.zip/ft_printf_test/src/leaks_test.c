/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_test.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vmonteco                                   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/05/04 01:23:12 by vmonteco          #+#    #+#             */
/*   Updated: 2017/05/17 17:11:15 by vmonteco         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */
/*                                                                            */
/*                                   headers                                  */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <wchar.h>
#include <limits.h>
#include <sys/wait.h>
#include <stddef.h>
#include "libftprintf.h"


/* ************************************************************************** */
/*                                                                            */
/*                       Macros to tests in child processes                   */
/*                              and to get the result.                        */
/*                                                                            */
/* ************************************************************************** */

#define TEST(...)  ft_printf(__VA_ARGS__)


/* ************************************************************************** */
/*                                                                            */
/*                               actual tests                                 */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */
/*                                subtests                                    */
/* ************************************************************************** */

#define TEST_NUM_DI_SUBTESTS(CS, VAL)			\
	TEST("%" CS, VAL);							\
	TEST("% " CS, VAL);							\
	TEST("%+" CS, VAL);							\
	TEST("%-" CS, VAL);							\
	TEST("% 0" CS, VAL);						\
	TEST("% -" CS, VAL);						\
	TEST("%+0" CS, VAL);						\
	TEST("%+-" CS, VAL);						\
	TEST("% 04" CS, VAL);						\
	TEST("% -4" CS, VAL);						\
	TEST("%+04" CS, VAL);						\
	TEST("%+-4" CS, VAL);						\
	TEST("% 0.4" CS, VAL);						\
	TEST("% -.4" CS, VAL);						\
	TEST("%+0.4" CS, VAL);						\
	TEST("%+-.4" CS, VAL);						\
	TEST("% 04.4" CS, VAL);						\
	TEST("% -4.4" CS, VAL);						\
	TEST("%+04.4" CS, VAL);						\
	TEST("%+-4.4" CS, VAL)

#define TEST_NUM_OXUOUX(CS, VAL)				\
	TEST("%" CS, VAL);							\
	TEST("%#" CS, VAL);							\
	TEST("%-" CS, VAL);							\
	TEST("%0" CS, VAL);							\
	TEST("%#-" CS, VAL);						\
	TEST("%#0" CS, VAL);						\
	TEST("%14" CS, VAL);						\
	TEST("%#14" CS, VAL);						\
	TEST("%-14" CS, VAL);						\
	TEST("%014" CS, VAL);						\
	TEST("%#-14" CS, VAL);						\
	TEST("%#014" CS, VAL);						\
	TEST("%14.4" CS, VAL);						\
	TEST("%#14.4" CS, VAL);						\
	TEST("%-14.4" CS, VAL);						\
	TEST("%014.4" CS, VAL);						\
	TEST("%#-14.4" CS, VAL);					\
	TEST("%#014.4" CS, VAL);					\
	TEST("%.4" CS, VAL);						\
	TEST("%#.4" CS, VAL);						\
	TEST("%-.4" CS, VAL);						\
	TEST("%0.4" CS, VAL);						\
	TEST("%#-.4" CS, VAL);						\
	TEST("%#0.4" CS, VAL)


#define TEST_NUM_UUU(CS, VAL)					\
	TEST("%" CS, VAL);							\
	TEST("%-" CS, VAL);							\
	TEST("%0" CS, VAL);							\
	TEST("%14" CS, VAL);						\
	TEST("%-14" CS, VAL);						\
	TEST("%014" CS, VAL);						\
	TEST("%14.4" CS, VAL);						\
	TEST("%-14.4" CS, VAL);						\
	TEST("%014.4" CS, VAL);						\
	TEST("%.4" CS, VAL);						\
	TEST("%-.4" CS, VAL);						\
	TEST("%0.4" CS, VAL)



#define TEST_NUM_P_SUBTESTS(VAL)				\
	TEST("%p", VAL);							\
	TEST("%-p", VAL);							\
	TEST("%14p", VAL);							\
	TEST("%-14p", VAL)

/* ************************************************************************** */
/*                                    raw                                     */
/* ************************************************************************** */

#define TESTS_RAW										\
	TEST("TEST");										\
	TEST("\n");											\
	TEST("foobar  foobar\tfoobar\nfoobarxiv\n\n\t\\.")


/* ************************************************************************** */
/*                                  percent                                   */
/* ************************************************************************** */

#define TESTS_PERCENT										\
	TEST("%%");												\
	TEST("foo%%");											\
	TEST("bar%%");											\
	TEST("foo%%bar");										\
	TEST("foo%%bar%%foobar%%barbar")


/* ************************************************************************** */
/*                               c conv spec                                  */
/* ************************************************************************** */

#define TESTS_C														\
	TEST("%c", 'a');												\
	TEST("%5c", 'a');												\
	TEST("%-c", 'a');												\
	TEST("%-5c", 'a');												\
	TEST("%lc", (wint_t)0x262D);									\
	TEST("%5lc", (wint_t)0x262D);									\
	TEST("%-lc", (wint_t)0x262D);									\
	TEST("%-5lc", (wint_t)0x262D);									\
	TEST("%lc", 0x262D);											\
	TEST("%5lc", 0x262D);											\
	TEST("%-lc", 0x262D);											\
	TEST("%-5lc", 0x262D)


/* ************************************************************************** */
/*                               C conv spec                                  */
/* ************************************************************************** */

#define TESTS_UC													\
	TEST("%C", 'a');												\
	TEST("%5C", 'a');												\
	TEST("%-C", 'a');												\
	TEST("%-5C", 'a');												\
	TEST("%C", (wint_t)0x262D);										\
	TEST("%5C", (wint_t)0x262D);									\
	TEST("%-C", (wint_t)0x262D);									\
	TEST("%-5C", (wint_t)0x262D);									\
	TEST("%C", 0x262D);												\
	TEST("%5C", 0x262D);											\
	TEST("%-C", 0x262D);											\
	TEST("%-5C", 0x262D)


/* ************************************************************************** */
/*                               s conv spec                                  */
/* ************************************************************************** */

#define TESTS_S														\
	TEST("%s", "c");												\
	TEST("%s$\n", "");												\
	TEST("%-s$\n", "");												\
	TEST("%10s$\n", "");											\
	TEST("%-10s$\n", "");											\
	TEST("%.2s$\n", "");											\
	TEST("%-.2s$\n", "");											\
	TEST("%10.2s$\n", "");											\
	TEST("%-10.2s$\n", "");											\
	TEST("%.6s$\n", "");											\
	TEST("%-.6s$\n", "");											\
	TEST("%10.6s$\n", "");											\
	TEST("%-10.6s$\n", "");											\
	TEST("%ls$\n", (wchar_t *) L"");								\
	TEST("%-ls$\n", (wchar_t *) L"");								\
	TEST("%10ls$\n", (wchar_t *) L"");								\
	TEST("%-10ls$\n", (wchar_t *) L"");								\
	TEST("%.2ls$\n", (wchar_t *) L"");								\
	TEST("%-.2ls$\n", (wchar_t *) L"");								\
	TEST("%10.2ls$\n", (wchar_t *) L"");							\
	TEST("%-10.2ls$\n", (wchar_t *) L"");							\
	TEST("%.6ls$\n", (wchar_t *) L"");								\
	TEST("%-.6ls$\n", (wchar_t *) L"");								\
	TEST("%10.6ls$\n", (wchar_t *) L"");							\
	TEST("%-10.6ls$\n", (wchar_t *) L"");							\
	TEST("%s$\n", NULL);											\
	TEST("%-s$\n", NULL);											\
	TEST("%10s$\n", NULL);											\
	TEST("%-10s$\n", NULL);											\
	TEST("%.2s$\n", NULL);											\
	TEST("%-.2s$\n", NULL);											\
	TEST("%10.2s$\n", NULL);										\
	TEST("%-10.2s$\n", NULL);										\
	TEST("%.6s$\n", NULL);											\
	TEST("%-.6s$\n", NULL);											\
	TEST("%10.6s$\n", NULL);										\
	TEST("%-10.6s$\n", NULL);										\
	TEST("%ls$\n", (wchar_t *) NULL);								\
	TEST("%-ls$\n", (wchar_t *) NULL);								\
	TEST("%10ls$\n", (wchar_t *) NULL);								\
	TEST("%-10ls$\n", (wchar_t *) NULL);							\
	TEST("%.2ls$\n", (wchar_t *) NULL);								\
	TEST("%-.2ls$\n", (wchar_t *) NULL);							\
	TEST("%10.2ls$\n", (wchar_t *) NULL);							\
	TEST("%-10.2ls$\n", (wchar_t *) NULL);							\
	TEST("%.6ls$\n", (wchar_t *) NULL);								\
	TEST("%-.6ls$\n", (wchar_t *) NULL);							\
	TEST("%10.6ls$\n", (wchar_t *) NULL);							\
	TEST("%-10.6ls$\n", (wchar_t *) NULL);							\
	TEST("%s$\n", "foo");											\
	TEST("%-s$\n", "foo");											\
	TEST("%10s$\n", "foo");											\
	TEST("%-10s$\n", "foo");										\
	TEST("%.2s$\n", "foo");											\
	TEST("%-.2s$\n", "foo");										\
	TEST("%10.2s$\n", "foo");										\
	TEST("%-10.2s$\n", "foo");										\
	TEST("%ls$\n", L"\x262D\x262D\x262D");							\
	TEST("%-ls$\n", L"\x262D\x262D\x262D");							\
	TEST("%10ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.ls$\n", L"\x262D\x262D\x262D");							\
	TEST("%-.ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.0ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-.0ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.0ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.0ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.1ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-.1ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.1ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.1ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.2ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-.2ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.2ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.2ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.3ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-.3ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.3ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.3ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.4ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-.4ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.4ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.4ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%.5ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-.5ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%10.5ls$\n", L"\x262D\x262D\x262D");						\
	TEST("%-10.5ls$\n", L"\x262D\x262D\x262D")


/* ************************************************************************** */
/*                               S conv spec                                  */
/* ************************************************************************** */

#define TESTS_US													\
	TEST("%S", L"S");												\
	TEST("%S$\n", L"\x262D\x262D\x262D");							\
	TEST("%-S$\n", L"\x262D\x262D\x262D");							\
	TEST("%10S$\n", L"\x262D\x262D\x262D");							\
	TEST("%-10S$\n", L"\x262D\x262D\x262D");						\
	TEST("%S$\n", L"");												\
	TEST("%-S$\n", L"");											\
	TEST("%10S$\n", L"");											\
	TEST("%-10S$\n", L"");											\
	TEST("%S$\n", (wchar_t *)NULL);									\
	TEST("%-S$\n", (wchar_t *)NULL);								\
	TEST("%10S$\n", (wchar_t *)NULL);								\
	TEST("%-10S$\n", (wchar_t *)NULL);								\
	TEST("%-10S$\n", (wchar_t *)NULL)


/* ************************************************************************** */
/*                               p conv spec                                  */
/* ************************************************************************** */

#define TESTS_P														\
	TEST_NUM_P_SUBTESTS(NULL);										\
	/* TEST_NUM_P_SUBTESTS(foo_str); */								\
	TEST_NUM_P_SUBTESTS((void *)ptr)


/* ************************************************************************** */
/*                               d conv spec                                  */
/* ************************************************************************** */

#define TESTS_D														\
	TEST_NUM_DI_SUBTESTS("d", 0);									\
	TEST_NUM_DI_SUBTESTS("lld", (long long) 0);						\
	TEST_NUM_DI_SUBTESTS("ld", (long) 0);							\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) 0);					\
	TEST_NUM_DI_SUBTESTS("hd", (short) 0);							\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) 0);						\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) 0);							\
	TEST_NUM_DI_SUBTESTS("d", 1);									\
	TEST_NUM_DI_SUBTESTS("lld", (long long) 1);						\
	TEST_NUM_DI_SUBTESTS("ld", (long) 1);							\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) 1);					\
	TEST_NUM_DI_SUBTESTS("hd", (short) 1);							\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) 1);						\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) 1);							\
	TEST_NUM_DI_SUBTESTS("d", -1);									\
	TEST_NUM_DI_SUBTESTS("lld", (long long) -1);					\
	TEST_NUM_DI_SUBTESTS("ld", (long) -1);							\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) -1);					\
	TEST_NUM_DI_SUBTESTS("hd", (short) -1);							\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) -1);						\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) -1);						\
	TEST_NUM_DI_SUBTESTS("d", SHRT_MIN);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) SHRT_MIN);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) SHRT_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) SHRT_MIN);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) SHRT_MIN);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) SHRT_MIN);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) SHRT_MIN);					\
	TEST_NUM_DI_SUBTESTS("d", SHRT_MAX);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) SHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) SHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) SHRT_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) SHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) SHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) SHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("d", USHRT_MAX);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) USHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) USHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) USHRT_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) USHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) USHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) USHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("d", CHAR_MIN);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) CHAR_MIN);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) CHAR_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) CHAR_MIN);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) CHAR_MIN);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) CHAR_MIN);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) CHAR_MIN);					\
	TEST_NUM_DI_SUBTESTS("d", CHAR_MAX);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) CHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) CHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) CHAR_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) CHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) CHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) CHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("d", UCHAR_MAX);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) UCHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) UCHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) UCHAR_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) UCHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) UCHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) UCHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("d", INT_MIN);								\
	TEST_NUM_DI_SUBTESTS("lld", (long long) INT_MIN);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) INT_MIN);						\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) INT_MIN);				\
	TEST_NUM_DI_SUBTESTS("hd", (short) INT_MIN);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) INT_MIN);					\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) INT_MIN);					\
	TEST_NUM_DI_SUBTESTS("d", INT_MAX);								\
	TEST_NUM_DI_SUBTESTS("lld", (long long) INT_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) INT_MAX);						\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) INT_MAX);				\
	TEST_NUM_DI_SUBTESTS("hd", (short) INT_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) INT_MAX);					\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) INT_MAX);					\
	TEST_NUM_DI_SUBTESTS("d", UINT_MAX);							\
	TEST_NUM_DI_SUBTESTS("lld", (long long) UINT_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) UINT_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) UINT_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) UINT_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) UINT_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) UINT_MAX);					\
	TEST_NUM_DI_SUBTESTS("lld", (long long) LONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) LONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) LONG_MIN);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) LONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) LONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) LONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("lld", (long long) LONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) LONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) LONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) LONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) LONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) LONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("lld", (long long) ULONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) ULONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) ULONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) ULONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) ULONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) ULONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("lld", (long long) LLONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) LLONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) LLONG_MIN);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) LLONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) LLONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) LLONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("lld", (long long) LLONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("ld", (long) LLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) LLONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) LLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) LLONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) LLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("lld", (long long) ULLONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("ld", (long) ULLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhd", (signed char) ULLONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hd", (short) ULLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("jd", (intmax_t) ULLONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zd", (size_t) ULLONG_MAX)
 

/* ************************************************************************** */
/*                               D conv spec                                  */
/* ************************************************************************** */

#define TESTS_UD													\
	TEST_NUM_DI_SUBTESTS("D",  0);									\
	TEST_NUM_DI_SUBTESTS("D",  1);									\
	TEST_NUM_DI_SUBTESTS("D",  -1);									\
	TEST_NUM_DI_SUBTESTS("D",  SHRT_MIN);							\
	TEST_NUM_DI_SUBTESTS("D",  SHRT_MAX);							\
	TEST_NUM_DI_SUBTESTS("D",  USHRT_MAX);							\
	TEST_NUM_DI_SUBTESTS("D",  CHAR_MIN);							\
	TEST_NUM_DI_SUBTESTS("D",  CHAR_MAX);							\
	TEST_NUM_DI_SUBTESTS("D",  UCHAR_MAX);							\
	TEST_NUM_DI_SUBTESTS("D",  INT_MIN);							\
	TEST_NUM_DI_SUBTESTS("D",  INT_MAX);							\
	TEST_NUM_DI_SUBTESTS("D",  UINT_MAX);							\
	TEST_NUM_DI_SUBTESTS("D", (int) LONG_MIN);						\
	TEST_NUM_DI_SUBTESTS("D", (int) LONG_MAX);						\
	TEST_NUM_DI_SUBTESTS("D", (int) ULONG_MAX);						\
	TEST_NUM_DI_SUBTESTS("D", (int) LLONG_MIN);						\
	TEST_NUM_DI_SUBTESTS("D", (int) LLONG_MAX);						\
	TEST_NUM_DI_SUBTESTS("D", (int) ULLONG_MAX)


/* ************************************************************************** */
/*                               i conv spec                                  */
/* ************************************************************************** */

#define TESTS_I														\
	TEST_NUM_DI_SUBTESTS("i", 0);									\
	TEST_NUM_DI_SUBTESTS("lli", (long long) 0);						\
	TEST_NUM_DI_SUBTESTS("li", (long) 0);							\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) 0);					\
	TEST_NUM_DI_SUBTESTS("hi", (short) 0);							\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) 0);						\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) 0);							\
	TEST_NUM_DI_SUBTESTS("i", 1);									\
	TEST_NUM_DI_SUBTESTS("lli", (long long) 1);						\
	TEST_NUM_DI_SUBTESTS("li", (long) 1);							\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) 1);					\
	TEST_NUM_DI_SUBTESTS("hi", (short) 1);							\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) 1);						\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) 1);							\
	TEST_NUM_DI_SUBTESTS("i", -1);									\
	TEST_NUM_DI_SUBTESTS("lli", (long long) -1);					\
	TEST_NUM_DI_SUBTESTS("li", (long) -1);							\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) -1);					\
	TEST_NUM_DI_SUBTESTS("hi", (short) -1);							\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) -1);						\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) -1);						\
	TEST_NUM_DI_SUBTESTS("i", SHRT_MIN);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) SHRT_MIN);				\
	TEST_NUM_DI_SUBTESTS("li", (long) SHRT_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) SHRT_MIN);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) SHRT_MIN);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) SHRT_MIN);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) SHRT_MIN);					\
	TEST_NUM_DI_SUBTESTS("i", SHRT_MAX);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) SHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) SHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) SHRT_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) SHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) SHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) SHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("i", USHRT_MAX);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) USHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) USHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) USHRT_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) USHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) USHRT_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) USHRT_MAX);					\
	TEST_NUM_DI_SUBTESTS("i", CHAR_MIN);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) CHAR_MIN);				\
	TEST_NUM_DI_SUBTESTS("li", (long) CHAR_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) CHAR_MIN);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) CHAR_MIN);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) CHAR_MIN);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) CHAR_MIN);					\
	TEST_NUM_DI_SUBTESTS("i", CHAR_MAX);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) CHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) CHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) CHAR_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) CHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) CHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) CHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("i", UCHAR_MAX);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) UCHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) UCHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) UCHAR_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) UCHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) UCHAR_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) UCHAR_MAX);					\
	TEST_NUM_DI_SUBTESTS("i", INT_MIN);								\
	TEST_NUM_DI_SUBTESTS("lli", (long long) INT_MIN);				\
	TEST_NUM_DI_SUBTESTS("li", (long) INT_MIN);						\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) INT_MIN);				\
	TEST_NUM_DI_SUBTESTS("hi", (short) INT_MIN);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) INT_MIN);					\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) INT_MIN);					\
	TEST_NUM_DI_SUBTESTS("i", INT_MAX);								\
	TEST_NUM_DI_SUBTESTS("lli", (long long) INT_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) INT_MAX);						\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) INT_MAX);				\
	TEST_NUM_DI_SUBTESTS("hi", (short) INT_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) INT_MAX);					\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) INT_MAX);					\
	TEST_NUM_DI_SUBTESTS("i", UINT_MAX);							\
	TEST_NUM_DI_SUBTESTS("lli", (long long) UINT_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) UINT_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) UINT_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) UINT_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) UINT_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) UINT_MAX);					\
	TEST_NUM_DI_SUBTESTS("lli", (long long) LONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("li", (long) LONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) LONG_MIN);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) LONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) LONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) LONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("lli", (long long) LONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) LONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) LONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) LONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) LONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) LONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("lli", (long long) ULONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) ULONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) ULONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) ULONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) ULONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) ULONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("lli", (long long) LLONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("li", (long) LLONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) LLONG_MIN);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) LLONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) LLONG_MIN);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) LLONG_MIN);					\
	TEST_NUM_DI_SUBTESTS("lli", (long long) LLONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("li", (long) LLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) LLONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) LLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) LLONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) LLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("lli", (long long) ULLONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("li", (long) ULLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("hhi", (signed char) ULLONG_MAX);			\
	TEST_NUM_DI_SUBTESTS("hi", (short) ULLONG_MAX);					\
	TEST_NUM_DI_SUBTESTS("ji", (intmax_t) ULLONG_MAX);				\
	TEST_NUM_DI_SUBTESTS("zi", (size_t) ULLONG_MAX)


/* ************************************************************************** */
/*                               o conv spec                                  */
/* ************************************************************************** */

#define TESTS_O														\
	TEST_NUM_OXUOUX("o", 0);										\
	TEST_NUM_OXUOUX("hho", (unsigned char) 0);						\
	TEST_NUM_OXUOUX("ho", (unsigned short) 0);						\
	TEST_NUM_OXUOUX("llo", (unsigned long long) 0);					\
	TEST_NUM_OXUOUX("lo", (unsigned long)0);						\
	TEST_NUM_OXUOUX("jo", (uintmax_t) 0);							\
	TEST_NUM_OXUOUX("zo", (size_t) 0);								\
	TEST_NUM_OXUOUX("o", 1);										\
	TEST_NUM_OXUOUX("hho", (unsigned char) 1);						\
	TEST_NUM_OXUOUX("ho", (unsigned short) 1);						\
	TEST_NUM_OXUOUX("llo", (unsigned long long) 1);					\
	TEST_NUM_OXUOUX("lo", (unsigned long) 1);						\
	TEST_NUM_OXUOUX("jo", (uintmax_t) 1);							\
	TEST_NUM_OXUOUX("zo", (size_t) 1);								\
	TEST_NUM_OXUOUX("o", -1);										\
	TEST_NUM_OXUOUX("hho", (unsigned char) -1);						\
	TEST_NUM_OXUOUX("ho", (unsigned short) -1);						\
	TEST_NUM_OXUOUX("llo", (unsigned long long) -1);				\
	TEST_NUM_OXUOUX("lo", (unsigned long) -1);						\
	TEST_NUM_OXUOUX("jo", (uintmax_t) -1);							\
	TEST_NUM_OXUOUX("zo", (size_t) -1);								\
	TEST_NUM_OXUOUX("o", SHRT_MIN);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) SHRT_MIN);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) SHRT_MIN);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) SHRT_MIN);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) SHRT_MIN);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) SHRT_MIN);					\
	TEST_NUM_OXUOUX("zo", (size_t) SHRT_MIN);						\
	TEST_NUM_OXUOUX("o", SHRT_MAX);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) SHRT_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) SHRT_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) SHRT_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) SHRT_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) SHRT_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) SHRT_MAX);						\
	TEST_NUM_OXUOUX("o", USHRT_MAX);								\
	TEST_NUM_OXUOUX("hho", (unsigned char) USHRT_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) USHRT_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) USHRT_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) USHRT_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) USHRT_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) USHRT_MAX);						\
	TEST_NUM_OXUOUX("o", CHAR_MIN);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) CHAR_MIN);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) CHAR_MIN);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) CHAR_MIN);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) CHAR_MIN);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) CHAR_MIN);					\
	TEST_NUM_OXUOUX("zo", (size_t) CHAR_MIN);						\
	TEST_NUM_OXUOUX("o", CHAR_MAX);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) CHAR_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) CHAR_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) CHAR_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) CHAR_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) CHAR_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) CHAR_MAX);						\
	TEST_NUM_OXUOUX("o", UCHAR_MAX);								\
	TEST_NUM_OXUOUX("hho", (unsigned char) UCHAR_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) UCHAR_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) UCHAR_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) UCHAR_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) UCHAR_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) UCHAR_MAX);						\
	TEST_NUM_OXUOUX("o", INT_MIN);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) INT_MIN);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) INT_MIN);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) INT_MIN);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) INT_MIN);					\
	TEST_NUM_OXUOUX("jo", (uintmax_t) INT_MIN);						\
	TEST_NUM_OXUOUX("zo", (size_t) INT_MIN);						\
	TEST_NUM_OXUOUX("o", INT_MAX);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) INT_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) INT_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) INT_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) INT_MAX);					\
	TEST_NUM_OXUOUX("jo", (uintmax_t) INT_MAX);						\
	TEST_NUM_OXUOUX("zo", (size_t) INT_MAX);						\
	TEST_NUM_OXUOUX("o", UINT_MAX);									\
	TEST_NUM_OXUOUX("hho", (unsigned char) UINT_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) UINT_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) UINT_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) UINT_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) UINT_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) UINT_MAX);						\
	TEST_NUM_OXUOUX("o", (unsigned int) LONG_MIN);					\
	TEST_NUM_OXUOUX("hho", (unsigned char) LONG_MIN);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) LONG_MIN);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) LONG_MIN);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) LONG_MIN);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) LONG_MIN);					\
	TEST_NUM_OXUOUX("zo", (size_t) LONG_MIN);						\
	TEST_NUM_OXUOUX("o", (unsigned int) LONG_MAX);					\
	TEST_NUM_OXUOUX("hho", (unsigned char) LONG_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) LONG_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) LONG_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) LONG_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) LONG_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) LONG_MAX);						\
	TEST_NUM_OXUOUX("o", (unsigned int) ULONG_MAX);					\
	TEST_NUM_OXUOUX("hho", (unsigned char) ULONG_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) ULONG_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) ULONG_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) ULONG_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) ULONG_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) ULONG_MAX);						\
	TEST_NUM_OXUOUX("o", (unsigned int) LLONG_MIN);					\
	TEST_NUM_OXUOUX("hho", (unsigned char) LLONG_MIN);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) LLONG_MIN);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) LLONG_MIN);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) LLONG_MIN);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) LLONG_MIN);					\
	TEST_NUM_OXUOUX("zo", (size_t) LLONG_MIN);						\
	TEST_NUM_OXUOUX("o", (unsigned int) LLONG_MAX);					\
	TEST_NUM_OXUOUX("hho", (unsigned char) LLONG_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) LLONG_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) LLONG_MAX);			\
	TEST_NUM_OXUOUX("lo", (unsigned long) LLONG_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) LLONG_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) LLONG_MAX);						\
	TEST_NUM_OXUOUX("o", (unsigned int) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("hho", (unsigned char) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("ho", (unsigned short) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("llo", (unsigned long long) ULLONG_MAX);		\
	TEST_NUM_OXUOUX("lo", (unsigned long) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("jo", (uintmax_t) ULLONG_MAX);					\
	TEST_NUM_OXUOUX("zo", (size_t) ULLONG_MAX)


/* ************************************************************************** */
/*                               O conv spec                                  */
/* ************************************************************************** */

#define TESTS_UO													\
	TEST_NUM_OXUOUX("O",  0);										\
	TEST_NUM_OXUOUX("O",  1);										\
	TEST_NUM_OXUOUX("O",  -1);										\
	TEST_NUM_OXUOUX("O",  SHRT_MIN);								\
	TEST_NUM_OXUOUX("O",  SHRT_MAX);								\
	TEST_NUM_OXUOUX("O",  USHRT_MAX);								\
	TEST_NUM_OXUOUX("O",  CHAR_MIN);								\
	TEST_NUM_OXUOUX("O",  CHAR_MAX);								\
	TEST_NUM_OXUOUX("O",  UCHAR_MAX);								\
	TEST_NUM_OXUOUX("O",  INT_MIN);									\
	TEST_NUM_OXUOUX("O",  INT_MAX);									\
	TEST_NUM_OXUOUX("O",  UINT_MAX);								\
	TEST_NUM_OXUOUX("O", (unsigned int) LONG_MIN);					\
	TEST_NUM_OXUOUX("O", (unsigned int) LONG_MAX);					\
	TEST_NUM_OXUOUX("O", (unsigned int) ULONG_MAX);					\
	TEST_NUM_OXUOUX("O", (unsigned int) LLONG_MIN);					\
	TEST_NUM_OXUOUX("O", (unsigned int) LLONG_MAX);					\
	TEST_NUM_OXUOUX("O", (unsigned int) ULLONG_MAX)


/* ************************************************************************** */
/*                               u conv spec                                  */
/* ************************************************************************** */

#define TESTS_U														\
	TEST_NUM_UUU("u", 0);											\
	TEST_NUM_UUU("hhu", (unsigned char) 0);							\
	TEST_NUM_UUU("hu", (unsigned short) 0);							\
	TEST_NUM_UUU("llu", (unsigned long long) 0);					\
	TEST_NUM_UUU("lu", (unsigned long)0);							\
	TEST_NUM_UUU("ju", (uintmax_t) 0);								\
	TEST_NUM_UUU("zu", (size_t) 0);									\
	TEST_NUM_UUU("u", 1);											\
	TEST_NUM_UUU("hhu", (unsigned char) 1);							\
	TEST_NUM_UUU("hu", (unsigned short) 1);							\
	TEST_NUM_UUU("llu", (unsigned long long) 1);					\
	TEST_NUM_UUU("lu", (unsigned long) 1);							\
	TEST_NUM_UUU("ju", (uintmax_t) 1);								\
	TEST_NUM_UUU("zu", (size_t) 1);									\
	TEST_NUM_UUU("u", -1);											\
	TEST_NUM_UUU("hhu", (unsigned char) -1);						\
	TEST_NUM_UUU("hu", (unsigned short) -1);						\
	TEST_NUM_UUU("llu", (unsigned long long) -1);					\
	TEST_NUM_UUU("lu", (unsigned long) -1);							\
	TEST_NUM_UUU("ju", (uintmax_t) -1);								\
	TEST_NUM_UUU("zu", (size_t) -1);								\
	TEST_NUM_UUU("u", SHRT_MIN);									\
	TEST_NUM_UUU("hhu", (unsigned char) SHRT_MIN);					\
	TEST_NUM_UUU("hu", (unsigned short) SHRT_MIN);					\
	TEST_NUM_UUU("llu", (unsigned long long) SHRT_MIN);				\
	TEST_NUM_UUU("lu", (unsigned long) SHRT_MIN);					\
	TEST_NUM_UUU("ju", (uintmax_t) SHRT_MIN);						\
	TEST_NUM_UUU("zu", (size_t) SHRT_MIN);							\
	TEST_NUM_UUU("u", SHRT_MAX);									\
	TEST_NUM_UUU("hhu", (unsigned char) SHRT_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) SHRT_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) SHRT_MAX);				\
	TEST_NUM_UUU("lu", (unsigned long) SHRT_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) SHRT_MAX);						\
	TEST_NUM_UUU("zu", (size_t) SHRT_MAX);							\
	TEST_NUM_UUU("u", USHRT_MAX);									\
	TEST_NUM_UUU("hhu", (unsigned char) USHRT_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) USHRT_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) USHRT_MAX);			\
	TEST_NUM_UUU("lu", (unsigned long) USHRT_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) USHRT_MAX);						\
	TEST_NUM_UUU("zu", (size_t) USHRT_MAX);							\
	TEST_NUM_UUU("u", CHAR_MIN);									\
	TEST_NUM_UUU("hhu", (unsigned char) CHAR_MIN);					\
	TEST_NUM_UUU("hu", (unsigned short) CHAR_MIN);					\
	TEST_NUM_UUU("llu", (unsigned long long) CHAR_MIN);				\
	TEST_NUM_UUU("lu", (unsigned long) CHAR_MIN);					\
	TEST_NUM_UUU("ju", (uintmax_t) CHAR_MIN);						\
	TEST_NUM_UUU("zu", (size_t) CHAR_MIN);							\
	TEST_NUM_UUU("u", CHAR_MAX);									\
	TEST_NUM_UUU("hhu", (unsigned char) CHAR_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) CHAR_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) CHAR_MAX);				\
	TEST_NUM_UUU("lu", (unsigned long) CHAR_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) CHAR_MAX);						\
	TEST_NUM_UUU("zu", (size_t) CHAR_MAX);							\
	TEST_NUM_UUU("u", UCHAR_MAX);									\
	TEST_NUM_UUU("hhu", (unsigned char) UCHAR_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) UCHAR_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) UCHAR_MAX);			\
	TEST_NUM_UUU("lu", (unsigned long) UCHAR_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) UCHAR_MAX);						\
	TEST_NUM_UUU("zu", (size_t) UCHAR_MAX);							\
	TEST_NUM_UUU("u", INT_MIN);										\
	TEST_NUM_UUU("hhu", (unsigned char) INT_MIN);					\
	TEST_NUM_UUU("hu", (unsigned short) INT_MIN);					\
	TEST_NUM_UUU("llu", (unsigned long long) INT_MIN);				\
	TEST_NUM_UUU("lu", (unsigned long) INT_MIN);					\
	TEST_NUM_UUU("ju", (uintmax_t) INT_MIN);						\
	TEST_NUM_UUU("zu", (size_t) INT_MIN);							\
	TEST_NUM_UUU("u", INT_MAX);										\
	TEST_NUM_UUU("hhu", (unsigned char) INT_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) INT_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) INT_MAX);				\
	TEST_NUM_UUU("lu", (unsigned long) INT_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) INT_MAX);						\
	TEST_NUM_UUU("zu", (size_t) INT_MAX);							\
	TEST_NUM_UUU("u", UINT_MAX);									\
	TEST_NUM_UUU("hhu", (unsigned char) UINT_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) UINT_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) UINT_MAX);				\
	TEST_NUM_UUU("lu", (unsigned long) UINT_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) UINT_MAX);						\
	TEST_NUM_UUU("zu", (size_t) UINT_MAX);							\
	TEST_NUM_UUU("u", (unsigned int) LONG_MIN);						\
	TEST_NUM_UUU("hhu", (unsigned char) LONG_MIN);					\
	TEST_NUM_UUU("hu", (unsigned short) LONG_MIN);					\
	TEST_NUM_UUU("llu", (unsigned long long) LONG_MIN);				\
	TEST_NUM_UUU("lu", (unsigned long) LONG_MIN);					\
	TEST_NUM_UUU("ju", (uintmax_t) LONG_MIN);						\
	TEST_NUM_UUU("zu", (size_t) LONG_MIN);							\
	TEST_NUM_UUU("u", (unsigned int) LONG_MAX);						\
	TEST_NUM_UUU("hhu", (unsigned char) LONG_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) LONG_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) LONG_MAX);				\
	TEST_NUM_UUU("lu", (unsigned long) LONG_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) LONG_MAX);						\
	TEST_NUM_UUU("zu", (size_t) LONG_MAX);							\
	TEST_NUM_UUU("u", (unsigned int) ULONG_MAX);					\
	TEST_NUM_UUU("hhu", (unsigned char) ULONG_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) ULONG_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) ULONG_MAX);			\
	TEST_NUM_UUU("lu", (unsigned long) ULONG_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) ULONG_MAX);						\
	TEST_NUM_UUU("zu", (size_t) ULONG_MAX);							\
	TEST_NUM_UUU("u", (unsigned int) LLONG_MIN);					\
	TEST_NUM_UUU("hhu", (unsigned char) LLONG_MIN);					\
	TEST_NUM_UUU("hu", (unsigned short) LLONG_MIN);					\
	TEST_NUM_UUU("llu", (unsigned long long) LLONG_MIN);			\
	TEST_NUM_UUU("lu", (unsigned long) LLONG_MIN);					\
	TEST_NUM_UUU("ju", (uintmax_t) LLONG_MIN);						\
	TEST_NUM_UUU("zu", (size_t) LLONG_MIN);							\
	TEST_NUM_UUU("u", (unsigned int) LLONG_MAX);					\
	TEST_NUM_UUU("hhu", (unsigned char) LLONG_MAX);					\
	TEST_NUM_UUU("hu", (unsigned short) LLONG_MAX);					\
	TEST_NUM_UUU("llu", (unsigned long long) LLONG_MAX);			\
	TEST_NUM_UUU("lu", (unsigned long) LLONG_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) LLONG_MAX);						\
	TEST_NUM_UUU("zu", (size_t) LLONG_MAX);							\
	TEST_NUM_UUU("u", (unsigned int) ULLONG_MAX);					\
	TEST_NUM_UUU("hhu", (unsigned char) ULLONG_MAX);				\
	TEST_NUM_UUU("hu", (unsigned short) ULLONG_MAX);				\
	TEST_NUM_UUU("llu", (unsigned long long) ULLONG_MAX);			\
	TEST_NUM_UUU("lu", (unsigned long) ULLONG_MAX);					\
	TEST_NUM_UUU("ju", (uintmax_t) ULLONG_MAX);						\
	TEST_NUM_UUU("zu", (size_t) ULLONG_MAX)


/* ************************************************************************** */
/*                               U conv spec                                  */
/* ************************************************************************** */

#define TESTS_UU													\
	TEST_NUM_UUU("U",  0);											\
	TEST_NUM_UUU("U",  1);											\
	TEST_NUM_UUU("U",  -1);											\
	TEST_NUM_UUU("U",  SHRT_MIN);									\
	TEST_NUM_UUU("U",  SHRT_MAX);									\
	TEST_NUM_UUU("U",  USHRT_MAX);									\
	TEST_NUM_UUU("U",  CHAR_MIN);									\
	TEST_NUM_UUU("U",  CHAR_MAX);									\
	TEST_NUM_UUU("U",  UCHAR_MAX);									\
	TEST_NUM_UUU("U",  INT_MIN);									\
	TEST_NUM_UUU("U",  INT_MAX);									\
	TEST_NUM_UUU("U",  UINT_MAX);									\
	TEST_NUM_UUU("U", (unsigned int) LONG_MIN);						\
	TEST_NUM_UUU("U", (unsigned int) LONG_MAX);						\
	TEST_NUM_UUU("U", (unsigned int) ULONG_MAX);					\
	TEST_NUM_UUU("U", (unsigned int) LLONG_MIN);					\
	TEST_NUM_UUU("U", (unsigned int) LLONG_MAX);					\
	TEST_NUM_UUU("U", (unsigned int) ULLONG_MAX)


/* ************************************************************************** */
/*                               x conv spec                                  */
/* ************************************************************************** */

#define TESTS_X														\
	TEST_NUM_OXUOUX("x", 0);										\
	TEST_NUM_OXUOUX("hhx", (unsigned char) 0);						\
	TEST_NUM_OXUOUX("hx", (unsigned short) 0);						\
	TEST_NUM_OXUOUX("llx", (unsigned long long) 0);					\
	TEST_NUM_OXUOUX("lx", (unsigned long)0);						\
	TEST_NUM_OXUOUX("jx", (uintmax_t) 0);							\
	TEST_NUM_OXUOUX("zx", (size_t) 0);								\
	TEST_NUM_OXUOUX("x", 1);										\
	TEST_NUM_OXUOUX("hhx", (unsigned char) 1);						\
	TEST_NUM_OXUOUX("hx", (unsigned short) 1);						\
	TEST_NUM_OXUOUX("llx", (unsigned long long) 1);					\
	TEST_NUM_OXUOUX("lx", (unsigned long) 1);						\
	TEST_NUM_OXUOUX("jx", (uintmax_t) 1);							\
	TEST_NUM_OXUOUX("zx", (size_t) 1);								\
	TEST_NUM_OXUOUX("x", -1);										\
	TEST_NUM_OXUOUX("hhx", (unsigned char) -1);						\
	TEST_NUM_OXUOUX("hx", (unsigned short) -1);						\
	TEST_NUM_OXUOUX("llx", (unsigned long long) -1);				\
	TEST_NUM_OXUOUX("lx", (unsigned long) -1);						\
	TEST_NUM_OXUOUX("jx", (uintmax_t) -1);							\
	TEST_NUM_OXUOUX("zx", (size_t) -1);								\
	TEST_NUM_OXUOUX("x", SHRT_MIN);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) SHRT_MIN);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) SHRT_MIN);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) SHRT_MIN);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) SHRT_MIN);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) SHRT_MIN);					\
	TEST_NUM_OXUOUX("zx", (size_t) SHRT_MIN);						\
	TEST_NUM_OXUOUX("x", SHRT_MAX);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) SHRT_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) SHRT_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) SHRT_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) SHRT_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) SHRT_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) SHRT_MAX);						\
	TEST_NUM_OXUOUX("x", USHRT_MAX);								\
	TEST_NUM_OXUOUX("hhx", (unsigned char) USHRT_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) USHRT_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) USHRT_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) USHRT_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) USHRT_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) USHRT_MAX);						\
	TEST_NUM_OXUOUX("x", CHAR_MIN);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) CHAR_MIN);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) CHAR_MIN);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) CHAR_MIN);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) CHAR_MIN);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) CHAR_MIN);					\
	TEST_NUM_OXUOUX("zx", (size_t) CHAR_MIN);						\
	TEST_NUM_OXUOUX("x", CHAR_MAX);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) CHAR_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) CHAR_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) CHAR_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) CHAR_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) CHAR_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) CHAR_MAX);						\
	TEST_NUM_OXUOUX("x", UCHAR_MAX);								\
	TEST_NUM_OXUOUX("hhx", (unsigned char) UCHAR_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) UCHAR_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) UCHAR_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) UCHAR_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) UCHAR_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) UCHAR_MAX);						\
	TEST_NUM_OXUOUX("x", INT_MIN);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) INT_MIN);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) INT_MIN);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) INT_MIN);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) INT_MIN);					\
	TEST_NUM_OXUOUX("jx", (uintmax_t) INT_MIN);						\
	TEST_NUM_OXUOUX("zx", (size_t) INT_MIN);						\
	TEST_NUM_OXUOUX("x", INT_MAX);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) INT_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) INT_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) INT_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) INT_MAX);					\
	TEST_NUM_OXUOUX("jx", (uintmax_t) INT_MAX);						\
	TEST_NUM_OXUOUX("zx", (size_t) INT_MAX);						\
	TEST_NUM_OXUOUX("x", UINT_MAX);									\
	TEST_NUM_OXUOUX("hhx", (unsigned char) UINT_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) UINT_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) UINT_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) UINT_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) UINT_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) UINT_MAX);						\
	TEST_NUM_OXUOUX("x", (unsigned int) LONG_MIN);					\
	TEST_NUM_OXUOUX("hhx", (unsigned char) LONG_MIN);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) LONG_MIN);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) LONG_MIN);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) LONG_MIN);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) LONG_MIN);					\
	TEST_NUM_OXUOUX("zx", (size_t) LONG_MIN);						\
	TEST_NUM_OXUOUX("x", (unsigned int) LONG_MAX);					\
	TEST_NUM_OXUOUX("hhx", (unsigned char) LONG_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) LONG_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) LONG_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) LONG_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) LONG_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) LONG_MAX);						\
	TEST_NUM_OXUOUX("x", (unsigned int) ULONG_MAX);					\
	TEST_NUM_OXUOUX("hhx", (unsigned char) ULONG_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) ULONG_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) ULONG_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) ULONG_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) ULONG_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) ULONG_MAX);						\
	TEST_NUM_OXUOUX("x", (unsigned int) LLONG_MIN);					\
	TEST_NUM_OXUOUX("hhx", (unsigned char) LLONG_MIN);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) LLONG_MIN);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) LLONG_MIN);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) LLONG_MIN);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) LLONG_MIN);					\
	TEST_NUM_OXUOUX("zx", (size_t) LLONG_MIN);						\
	TEST_NUM_OXUOUX("x", (unsigned int) LLONG_MAX);					\
	TEST_NUM_OXUOUX("hhx", (unsigned char) LLONG_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) LLONG_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) LLONG_MAX);			\
	TEST_NUM_OXUOUX("lx", (unsigned long) LLONG_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) LLONG_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) LLONG_MAX);						\
	TEST_NUM_OXUOUX("x", (unsigned int) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("hhx", (unsigned char) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("hx", (unsigned short) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("llx", (unsigned long long) ULLONG_MAX);		\
	TEST_NUM_OXUOUX("lx", (unsigned long) ULLONG_MAX);				\
	TEST_NUM_OXUOUX("jx", (uintmax_t) ULLONG_MAX);					\
	TEST_NUM_OXUOUX("zx", (size_t) ULLONG_MAX);

	
/* ************************************************************************** */
/*                               X conv spec                                  */
/* ************************************************************************** */

#define TESTS_UX													\
	TEST_NUM_OXUOUX("X",  0);										\
	TEST_NUM_OXUOUX("X",  1);										\
	TEST_NUM_OXUOUX("X",  -1);										\
	TEST_NUM_OXUOUX("X",  SHRT_MIN);								\
	TEST_NUM_OXUOUX("X",  SHRT_MAX);								\
	TEST_NUM_OXUOUX("X",  USHRT_MAX);								\
	TEST_NUM_OXUOUX("X",  CHAR_MIN);								\
	TEST_NUM_OXUOUX("X",  CHAR_MAX);								\
	TEST_NUM_OXUOUX("X",  UCHAR_MAX);								\
	TEST_NUM_OXUOUX("X",  INT_MIN);									\
	TEST_NUM_OXUOUX("X",  INT_MAX);									\
	TEST_NUM_OXUOUX("X",  UINT_MAX);								\
	TEST_NUM_OXUOUX("X", (unsigned int) LONG_MIN);					\
	TEST_NUM_OXUOUX("X", (unsigned int) LONG_MAX);					\
	TEST_NUM_OXUOUX("X", (unsigned int) ULONG_MAX);					\
	TEST_NUM_OXUOUX("X", (unsigned int) LLONG_MIN);					\
	TEST_NUM_OXUOUX("X", (unsigned int) LLONG_MAX);					\
	TEST_NUM_OXUOUX("X", (unsigned int) ULLONG_MAX)


/* ************************************************************************** */
/*                                  Misc.                                     */
/* ************************************************************************** */

#define TESTS_MISC														\
	TEST("%% %c %C %s %S %d %D %i %p %o %O %x %X %u %U",				\
		 'a', 0x262D, "a", L"\x262D", 42, 42, 42,						\
		 (void *) 424242, 42, 42424242, 42, 42424242, 42, 42424242)


/* ************************************************************************** */
/*                             test function                                  */
/* ************************************************************************** */

void	ft_printf_test_leaks(void)
{
	// values :
	/*char	*foo_str = "foo"; */
	void	*ptr = (void *)0x123afd;
	
	setlocale(LC_ALL, "");
	TESTS_RAW;
	TESTS_PERCENT;
	TESTS_C;
	TESTS_UC;
	TESTS_S;
	TESTS_US;
	TESTS_D;
	TESTS_UD;
	TESTS_I;
	TESTS_P;
	TESTS_O;
	TESTS_UO;
	TESTS_U;
	TESTS_UU;
	TESTS_X;
	TESTS_UX;
	TESTS_MISC;
	while (1);
}
