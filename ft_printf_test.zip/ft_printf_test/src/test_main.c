/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vmonteco                                   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/05/09 03:31:36 by vmonteco          #+#    #+#             */
/*   Updated: 2017/05/14 00:01:40 by vmonteco         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "ft_printf_test.h"

void	usage_error(void)
{
	printf("usage : ./ft_printf_test [-v|--verbose]\n");
	exit(EXIT_FAILURE);
}

int		main(int argc, char **argv)
{
	int		verbose;
	
	verbose = 0;
	if (argc == 1)
		verbose = 0;
	else if (argc == 2)
	{
		if (strcmp("-v", argv[1]) || strcmp("--verbose", argv[1]))
			verbose = 1;
		else
			usage_error();
	}
	else
		usage_error();	
	ft_printf_test(verbose);
	return (0);
}
